---
name: html-to-md
description: >-
  斜杠唤起。仅当用户输入 /html-to-md 时使用。后面可接页面 URL。
  把网页 HTML 转成 Agent 可读 Markdown：去掉导航页脚、合并重复段落、保留带链接的按钮文案。
disable-model-invocation: true
---

# HTML 转化成 Markdown（Agent 可读）

单独斜杠 `/html-to-md` 仍可用。单页走 `/page-affinity-probe` 且没有可打开的平行稿时，会读本说明抽正文，不要再让用户敲本斜杠。

## 核心命题

原始 HTML（尤其营销站）对 Agent 噪声高。本 Skill 把给定页面压成**可扫读的 Markdown 正文**；文首用**索引模块**只声明两个 URL：根 `llms.txt`、本页对应的人读 HTML。

## 范围（必守）

**要做**

| 项 | 要求 |
|----|------|
| 输入 | **页面 URL（优先）**；或本地 `.html`；或粘贴片段 |
| 抽取 | 定位主内容；去掉 nav / header / footer / 登录壳 / 购物车等 |
| 去重 | 合并连续重复标题/段落 |
| 语义 | 标题、列表、绝对链接、代码、表格；图片 alt |
| 带链接的按钮 | 有效 href → `[文案](URL)`；空链可注「无有效跳转」 |
| **索引模块** | MD **最上方**（`#` 之前）声明：根 llms URL + 对应 HTML 页面 URL（只声明 URL，不加清洗说明） |
| 输出 | `.md` + 对照报告（Part1 说明 + Part2 MD 预览）；报告**只提供下载 MD** |

**不要做**

- 在报告里提供「下载镜像 HTML」按钮  
- 用 YAML / 清洗 note 顶替索引模块  
- 整站导航、页脚备案、热线二维码  
- 丢掉有跳转的按钮文案  

## 索引模块（必做，只声明 URL）

```markdown
> ## 索引
> 根 llms：https://{站点根}/llms.txt
> 对应 HTML：https://{本页最终URL}
```

| 规则 | 说明 |
|------|------|
| 根 llms | 站点根约定路径（如 `https://www.huaweicloud.com/llms.txt`）；用户指定则用用户的 |
| 对应 HTML | 本次转换的源页面最终 URL（本案即人读页地址） |
| 写法 | 只写 URL；不写「查本站…」「待部署」等长说明（可达性记报告 Part1） |

## 输入

| 字段 | 必填 | 说明 |
|------|------|------|
| 页面 URL | 是 | 如 `https://agentorchard.huaweicloud.com/agentarts.html` |
| 本地 HTML / 片段 | 可选 | 抓不全时再给。不交也能跑。不要追问根 llms URL / 正文选择器 / 输出 slug |

根 llms 缺则 `{站点根}/llms.txt`；正文选择器由 Agent 自行定位。

## 工作流

```
Step 0  输入 URL / 本地 HTML；读本 Skill

Step 1  获取 HTML；去 script/style

Step 2  定位正文；去壳

Step 3  生成 MD
        · 先写索引模块（根 llms + 对应 HTML，仅 URL）
        · 再 # 标题 + 导语 + 章节 + 带链接的按钮文案
        · 不加 YAML 清洗声明

Step 4  质检

Step 5  输出
        · exports/{slug}.md
        · html-to-md-{slug}.html（对照报告；顶栏/正文仅「下载 Markdown」）
        · docs/ 与 report-serve/ 双写
```

## Agent 可读规则

1. 一页一主题；短而全；命令可复制  
2. 索引模块只服务「根 llms + 本页 HTML」两个指针  
3. 表格保持表格  

## 壳层与布局（必须同构 robots-txt-audit）

| 规则 | 要求 |
|------|------|
| 侧栏 | **不要** `#module-sidebar` |
| 顶栏 | 品牌 + 下载 Markdown + 导出 PDF |
| 品牌 | 「AI 亲和原则」→ `https://liminshuo.github.io/ascend-ai/principles-overview.html` |
| 正文 | 内容栏最大 1000px；无站点导航 |
| 成品 | `docs/html-to-md-agentarts.html`；离线复制本目录 `report-template.html` |

## 报告结构

```
H1  HTML 转化成 Markdown · {页面简称}
page-meta  示例页面 · 实测日期 · 依据（Markdown 正文可直取）

Part1. 当前配置分析
  当前人读页（H3.aj-caption）
    URL 写在标题下（.page-lead），不要写进截图 figcaption
    现网截图 1920×1080、宽高比 16:9；不要用代码块标注 HTML
  问题判定（数字写进每条，不要另做来源表）

Part2. Markdown 建议稿
  下载 .md（不要镜像 HTML 下载）
  建议模板（行高 16px）
  修改说明
  待确认事项
```

### 建议稿着色

绿色 `.add` 只标清洗时改过的字（索引模块、去壳后的结构）。不要全篇 `.keep`。

## 调用示例

```
按 html-to-md 转换 https://agentorchard.huaweicloud.com/agentarts.html
MD 文首索引声明根 llms 与对应 HTML URL；报告只下载 .md。
```

## 输出落盘（GEO）

| 文件 | 说明 |
|------|------|
| `docs/exports/{slug}.md` | Agent 可读 MD（含索引模块） |
| `docs/html-to-md-{slug}.html` | 对照报告 |
| `report-serve/` 对应路径 | 同步副本 |
| `docs/exports/html-to-md.zip` | Skill 包 |

## 附加资源

- 可填壳模板：[report-template.html](report-template.html)
- `docs/principles-format.html`、`docs/principles-noise.html`、`docs/principles-llms.html`
