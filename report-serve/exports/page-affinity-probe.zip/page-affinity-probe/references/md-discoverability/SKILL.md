---
name: md-discoverability
description: >-
  斜杠唤起。仅当用户输入 /md-discoverability 时使用。后面可接人读页 URL。
  核验人读页是否声明平行 Markdown，以及对应文件能不能打开。不负责把 HTML 转成 Markdown。
disable-model-invocation: true
---

# Markdown 正文可发现

单独斜杠 `/md-discoverability` 仍可用。单页走 `/page-affinity-probe` 时会读本说明先核验再出稿，不要再让用户敲本斜杠。

## 核心命题

人读页（HTML）若要对 Agent **可发现**平行正文，应在 `<head>` 声明 Markdown 入口，且该 `.md` **公开可达**。本 Skill 只回答：声明有没有、指到哪里、能不能打开——**不**负责把 HTML 转成 MD。

成对关系：

| Skill | 职责 |
|-------|------|
| `html-to-md` | **生成** Agent 可读 `.md` |
| **`md-discoverability`（本 Skill）** | **核验**人读页能否发现平行 `.md` |

依据：`docs/principles-format.html`（Markdown 正文可直取 / alternate）；全量原则 **#7 双轨交付**（25 项口径，勿用旧 35 条）。

## 输入

| 字段 | 必填 | 说明 |
|------|------|------|
| 人读页 URL | 是 | 如 `https://agentorchard.huaweicloud.com/agentarts.html` |
| 预期 Markdown 地址 | 可选 | 知道准确地址时再给。不交则从页面声明或同路径 `.md` 推断。不要追问站点根 |

站点根由人读页 URL 推断，相对地址由 Agent 自行拼绝对路径。

## 范围

**要做**

1. GET 人读页；解析是否存在：
   - `<link rel="alternate" type="text/markdown" href="…">`
   - 等价：`data-link-type="markdown"` 等
2. 对声明 URL、用户给定 URL、同路径候选做可达性（状态码、Content-Type）
3. 可选轻量：`.md` 非空、是否含 `#` 标题（像正文）；不做全量内容审计
4. Part1 现状 + Part2 如何补声明 / 路径约定；HTML 报告；双写；zip

**不要做**

- 把 HTML 转成 MD（→ `html-to-md`）
- 深审 robots / sitemap / llms 全文（可一句带过发现链）
- 编造页上不存在的 `link` 标签

## 工作流

```
Step 0  输入人读页 URL（+ 可选预期 md / 站点根）
Step 1  GET HTML；收集 alternate / data-link-type=markdown
Step 2  解析绝对 md URL 列表；追加同路径 .md 候选（若未声明）
Step 3  逐个 HEAD/GET；记状态与 Content-Type
Step 4  若 200 且像 markdown：抽查是否有 # 标题、字节数
Step 5  出报告：缺失声明 / 声明不可达 / 达标；Part2 给建议 head 片段
Step 6  docs/ + report-serve/ 双写
```

## 问题判定

| 严重度 | 何时 |
|--------|------|
| **P0** | 无人读页可达，或业务要求双轨但完全无声明且候选全失败 |
| **P1** | 无 alternate 声明（仅有猜测路径也不算声明） |
| **P1** | 有声明但 .md 非 200 / 非 markdown 类型 |
| **P2** | 相对路径难解析、无 `#` 标题等轻量质量问题 |
| **OK** | 有声明且 .md 可达、像正文 |

## 报告结构

```
H1  Markdown 正文可发现 · {页面简称}
page-meta  示例页面 · 实测日期 · 依据（Markdown 正文可直取）

Part1. 当前配置分析
  当前人读页（带标注）
    能不能打开、有没有 alternate 声明、同路径 .md 能不能打开
  问题判定
    ol + P0/P1/P2；数字写进每条，不要另做探测表

Part2. 优化建议
  建议模板（写入人读页 head）
  修改说明
  待确认事项
```

顶栏：品牌 + 导出 PDF。正文最大 1000px。无侧栏、无站点导航。成品：`docs/md-discover-agentarts.html`；离线复制本目录 `report-template.html`。

### 建议稿着色

建议模板是写入人读页 `<head>` 的片段。绿色 `.add` 只标要补上的声明。不要全篇 `.keep`。

## 调用示例

```
按 md-discoverability 核验
https://agentorchard.huaweicloud.com/agentarts.html
输出诊断 HTML；无声明则如实记录并给补声明建议。
```

## 输出落盘（GEO）

| 文件 | 说明 |
|------|------|
| `docs/md-discover-{slug}.html` | 报告 |
| `docs/skill-md-discoverability.html` | Skill 详情 |
| `docs/exports/md-discoverability.zip` | Skill 包 |
| `report-serve/` 同步 | 双写 |

## 附加资源

- 可填壳模板：[report-template.html](report-template.html)
- `docs/principles-format.html`
- `docs/principles-full-catalog.html`（原则 7）
- 成对：`.cursor/skills/html-to-md/`
