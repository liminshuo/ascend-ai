---
name: page-affinity-probe
description: >-
  斜杠唤起。仅当用户输入 /page-affinity-probe 时使用。后面可接页面 URL。
  抽检一页：先看平行 Markdown 能不能打开，没有则先抽出正文，再按原则改稿。
  不要让用户再敲 /md-discoverability 或 /html-to-md。
disable-model-invocation: true
---

# 页级亲和探针

## 核心命题

这是**单页领队**。把它当作单页入口：对话里只敲 `/page-affinity-probe`，后面接页面地址。先判断有没有可打开的平行 Markdown；没有就从人读页抽正文；最后按原则改成可部署稿。

全站原则表有 **25 项**（若干含**子原则**）。本 Skill 对**一页**做可证伪实测：页面上碰得到什么组件/信号，就测对应原则与**子原则**。  
**报告不把 25 项整表贴进页面**；内部按子原则判定，对外只写缺失/待改进。站点入口类（robots / 全站 sitemap）仅在本页有机器发现标签或明确关联时才记一笔。

## 与其它 Skill 的分工

| Skill | 用途 |
|-------|------|
| **本 Skill `page-affinity-probe`** | 单页领队：发现平行稿 → 必要时抽正文 → 按原则改稿 |
| `md-discoverability` / `html-to-md` | 分项；本包 `references/` 已带，接力时直接执行 |
| `robots-txt-audit` / `sitemap-audit` / `llms-txt-generate` | 发现层配置；全站入口用 `/geo-checklist-audit` |
| 全站 Checklist | 站点根记分板 + 配置稿 |

依据真源：`docs/principles-full-catalog.html`（全量原则25项）。**禁止**再按旧「35 条」口径。

## 输入

| 字段 | 必填 | 说明 |
|------|------|------|
| 页面 URL | 是 | 文档页或产品页 |
| 本地 HTML | 可选 | 抓不全时再给。不交也能跑。不要追问产品名 / 关注组件 |

产品名从页面标题推断；关注组件按页上实际出现的测。

输入若是站点根（只有主机名或末尾 `/` 且无文档路径），问一句：查全站还是只改首页。查全站 → `/geo-checklist-audit`。不要在本 Skill 里改 robots / sitemap / llms。

## 接力出稿（单页，必做）

斜杠只唤起本 Skill。**禁止**让用户再敲 `/md-discoverability` 或 `/html-to-md`。下载本包即可完成这条流程，不必先装两个分项。分项仍可单独下载。

1. 按 `references/md-discoverability/SKILL.md` 核验：有没有 alternate 声明、`.md` 能不能打开。  
2. **能打开**：拉取该 MD **全文**作 Part2 底稿，禁止另写提纲。  
3. **打不开 / 没有声明**：按 `references/html-to-md/SKILL.md` 从人读页抽出正文（含文首索引模块），再以这份抽出稿为底做原则改稿。同时在修改说明里写清 `<head>` 如何声明平行 Markdown。  
4. 主交付仍是**一份**页级报告（问题判定 + 可部署 Markdown）+ 可下载 `.md`。不要再单独堆一份「只转写、不改原则」的对照报告，除非用户只要转写。  
5. 分项仍可单独下载、单独斜杠。

## 范围（必守）

**要做**

1. 拉取页面（或读本地 HTML），识别本页组件与相关原则/子原则。  
2. 可证伪实测：图 / 表 / 代码 / Tab / 折叠 / 隐藏语义 / 链接 / 锚点 / 警示 / 步骤结构 / 元数据与平行稿等——**碰到什么测什么**。  
3. **子原则单独判定**，禁止只判父原则「整体 OK」。内部可用：`达标` / `待改进` / `缺失` / `不适用`。  
4. 输出 HTML 报告：**Part1 现网截图 + 问题判定；Part2 平行 Markdown 建议稿 + 修改说明 + 待确认**。可导出 PDF。可下载 `.md`。  
5. GEO：`docs/` 与 `report-serve/` 双写；更新 zip；同步 `~/.cursor/skills/`。

**不要做**

- 编造页上不存在的组件结论  
- 把 25 项状态表或「问句 → 证据 → 洞察 → 根因」块写进报告  
- 用父原则一条盖住多个子原则  
- 把建议稿写成 HTML 源码或缩写提纲  
- 让用户再去斜杠调用发现 / 转写 Skill  
- 改全站 robots / sitemap / llms  
- 假装已做全站 25 项审计  

## 工作流

```
Step 0  读本 Skill + principles-full-catalog.html
        复制 [report-template.html](report-template.html) 填内容
        若输入是站点根：问一句，全站走 Checklist
Step 1  获取人读页；按 references/md-discoverability 核验平行 MD
Step 1b 平行稿可达则拉全文；否则按 references/html-to-md 抽正文
Step 2  映射到相关原则 / 子原则；无关不写进报告
Step 3  实测：alt、figure、pre/code 语言、heading 层级、
        alternate markdown、llms link、说明文字前缀、步骤 ol、验证区块等
Step 4  Part1 只列缺失/待改进（P0/P1/P2）；达标写进 Part2「已具备」
Step 5  Part2 以底稿全文改稿（见下方着色规则）；必要时补 head 声明
Step 6  输出 HTML + .md；双写；打 zip
```

## 壳层与布局（必须同构 robots-txt-audit）

| 规则 | 要求 |
|------|------|
| 侧栏 | **不要** `#module-sidebar` |
| 顶栏 | 仅品牌 + 导出 PDF；**不要**站点导航 |
| 品牌 | 「AI 亲和原则」→ `https://liminshuo.github.io/ascend-ai/principles-overview.html`（`target="_blank"`） |
| 顶栏对齐 | `.topbar-inner` 与正文同宽：`min(1000px, 100% - 2*gutter)` + `margin: 0 auto` |
| 正文 | `.page-wrapper` `padding-top: 56px`；主区白底；内容栏最大 1000px |
| 成品 | `docs/page-probe-codearts-vscode.html`；离线复制本目录 `report-template.html` |

## 报告结构（必须同构）

```
顶栏  品牌（左） · 导出 PDF（右）

H1  页级亲和探针 · {页面简称}
page-meta  示例页面 · 实测日期 · 依据（全量原则25项）

Part1. 当前配置分析
  当前人读页（H3.aj-caption）
    URL 写在标题下（.page-lead），不要和截图卡片混在一起
    现网截图 1920×1080、宽高比 16:9；不要用代码块标注 HTML
  问题判定（H3）
    ol + P0/P1/P2；数字写进每条，不要另做状态表 / 拉取结果表

Part2. 优化建议
  建议模板（H3.aj-caption）= 可部署的平行 Markdown，不是 HTML 源码
  修改说明
  待确认事项
```

## 建议稿规则

- **底稿**：现网平行 Markdown **全文**。不删准备工作、步骤、示例、链接、代码、图片地址。  
- **改什么**：标题层级（如 `####` → `##` / `###`）、空图片说明、代码语言、说明前缀（「说明：」）、路径末尾验收。  
- **着色**：绿色 `.add` **只标改过的字**。其余按原文，**不要全篇 `.keep`**。`.ask` 仅待确认。  
- 建议模板 `pre code` 行高 16px。

## 调用示例

```
/page-affinity-probe
https://support.huaweicloud.com/qs-codeartsagent/codeartsagent_qs_0002.html
```

## 输出落盘（GEO）

| 文件 | 说明 |
|------|------|
| `docs/page-probe-{slug}.html` | 示例/报告 |
| `report-serve/page-probe-{slug}.html` | 同步 |
| `docs/skill-page-affinity-probe.html` | Skill 详情 |
| `docs/exports/page-affinity-probe.zip` | Skill 包 |
| `.cursor/skills/page-affinity-probe/` | 仓库 Skill |
| `~/.cursor/skills/page-affinity-probe/` | 个人副本 |

## 附加资源

- 可填壳模板：[report-template.html](report-template.html)
- 接力说明：`references/md-discoverability/SKILL.md`、`references/html-to-md/SKILL.md`
- `docs/principles-full-catalog.html`
- 原则页：`docs/principles-image.html`、`docs/principles-code.html`
