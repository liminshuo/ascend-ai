---
name: learn-cann
description: >-
  斜杠唤起昇腾 CANN 学习旅程地图。仅当用户输入 /learn-cann 时使用。
  后面可接主题，例如 Ascend C 算子开发、大模型推理、训练、推荐、应用开发、
  图框架、集合通信、PyASC、CANNBot、RAG。没有主题时先问再出图。
disable-model-invocation: true
---

# /learn-cann

这是「CANN 学习旅程地图」的斜杠入口。被这条命令唤起后，第一步读取并严格遵循：

`cann-learning-journey/SKILL.md`（相对本目录）

按该文件的工作流执行 `cann-learning-journey/scripts/generate.py`，生成本地单文件学习旅程 HTML。不要只回文字大纲。

- 本条消息里如果已经写了学习主题，直接对应主题 key 出图。
- 如果只有 `/learn-cann`、没有主题，先问清主题再出图。主题 key 以那份 SKILL.md 为准。
