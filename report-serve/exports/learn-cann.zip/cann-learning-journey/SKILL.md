---
name: cann-learning-journey
description: >-
  Use when a user drops this skill into an Agent (e.g. Cursor) and says they want
  to learn CANN / 昇腾 topics — e.g. "我想学 Ascend C 算子开发", "想学大模型推理/训练",
  "了解 NPU/CANN", "学推荐/应用开发/图框架/集合通信/PyASC/CANNBot/RAG". Always generate a
  local single-file 学习旅程地图 HTML they can open and click through (课程/学习路径/认证
  cards → 昇腾社区 DLC). Do not answer with a plain text outline only. Link basis:
  README.md + scripts/topics.py (community_courses). Never use hub /developer/learn
  as a fake course landing.
agent_created: true
---

# CANN 学习旅程地图（Agent Skill）

## 场景（你要交付什么）

用户把本 Skill **拖入 Agent**（如 Cursor）后，发起一句学习意图，例如：

> 我想学 Ascend C 算子开发

Agent **必须自动生成本地 HTML 文件**（学习旅程地图），让用户打开后：

1. 看到竖向时间轴：公共基础 → 主题阶段 → 练习与认证  
2. **点击卡片**进入昇腾社区对应课程 / 路径 / 认证，一步步学  
3. 卡角标明资源类型（课程 / 学习路径 / 认证 / 练习平台 / 检索）

**禁止**只回文字大纲而不出 HTML。默认产物形态对齐示例页中的旅程地图（头图 + 画像 + 左右交替卡片 + 结业证书）。

## 链接查找依据（给大模型用）

查「学什么、点哪里」时，按此优先级：

| 优先级 | 依据 | 用途 |
| --- | --- | --- |
| 1 | [`README.md`](./README.md) | 人读总览：角色导航、五条主线、社区真链与资源类型 |
| 2 | [`scripts/topics.py`](./scripts/topics.py) | 机器真源：`community_courses`（标题=社区真名，link=详情页，type=类型） |
| 3 | [`references/intent-map.md`](./references/intent-map.md) | 意图词 → 主题 key 对照 |

卡片规则（硬约束）：

1. **标题 = 社区资源真名**，**链接 = 对应详情页**，同名同义。  
2. 标签写真实 **资源类型**，禁止一律「在线体验」。  
3. `/developer/learn` 是**枢纽页**，只可作页脚/总入口，**不得**当单课落地。  
4. 有 `community_courses` 时优先用它，勿用错位 Notebook 名挂社区页。

社区枢纽：https://www.hiascend.com/developer/learn  
查找资源：https://www.hiascend.com/developer/edu/find-resource

## When to use

- 用户表达 CANN / 昇腾**学习意图**（「我想学 / 怎么入门 / 学习路径」）。  
- 用户希望**可点击的可视化地图**，而非纯文字罗列。  
- 用户已安装/拖入本 Skill，并期望 Agent **直接出本地 HTML**。

### 触发词（主题 key）

| 说法 | key |
| --- | --- |
| 算子 / Ascend C / 自定义算子 | `operator` |
| 推理 / LLM 部署 / Qwen 推理 | `inference` |
| 训练 / 微调 / SFT / RL | `training` |
| 推荐 / DeepFM / CTR | `recommend` |
| 入门 CANN / NPU / 新手 | `basics` |
| 应用开发 / 离线推理 / ACL / ATC | `application` |
| 图框架 / GE / TorchAir / AutoFusion | `graph` |
| 集合通信 / HCCL / HiXL | `comm` |
| PyASC / PyPTO / Python 算子 | `pyasc` |
| CANNBot / AI 生成算子 | `cannbot` |
| AI 应用 / RAG / 知识库问答 | `ai_app` |

### 消歧

- 「我想**学** XXX」→ 本 Skill：跑 `generate.py` 出旅程地图 HTML。  
- 「新技术 / 案例 / 博客」→ `build_blog_wall.py`（卡片墙，非时间轴）。  
- 方向含糊（只说「开发」「了解 CANN」）→ **先问清主题**再出图。  
- 勿与全景网格 `/ascend-learning-journey` 混淆。

## Agent 工作流（默认路径）

命中学习意图后，**不要手写 HTML**，在本 Skill 根目录执行：

```bash
python3 scripts/generate.py \
  --topic <主题key> \
  --out ./out/<简短中文名>学习旅程.html \
  --role <角色或「开发人员」> \
  --goal <目标摘要>
```

示例：

```bash
python3 scripts/generate.py \
  --topic operator \
  --out ./out/AscendC算子开发学习旅程.html \
  --role 开发人员 \
  --goal 算子开发入门
```

脚本会：读 `topics.py` → 社区真名真链卡片 → 前置「CANN 基础知识」→ 追加练习/认证 → 渲染单文件 HTML。

### 交付给用户时

1. 用文件工具 / 系统方式打开或给出**本地绝对路径**，请用户用浏览器打开。  
2. 一句话说清：按时间轴点卡片即可进入社区学习；类型见卡角。  
3. 若用户改意图（换主题），重新跑 `generate.py` 覆盖或另存新文件。

### 工作目录

- 命令在 **本 Skill 目录**执行（与 `SKILL.md`、`scripts/`、`assets/` 同级）。  
- 若 Skill 装在 `~/.cursor/skills/cann-learning-journey/`，则：

```bash
cd ~/.cursor/skills/cann-learning-journey
python3 scripts/generate.py --topic operator --out ./out/AscendC算子开发学习旅程.html --role 开发人员 --goal 算子开发入门
```

- 也可把 `--out` 指到用户当前工程目录（便于在项目里找到文件）。

## 仅当需自定义时

组装 JSON 后渲染（字段须含 `type` + 社区详情 `link`）：

```bash
python3 scripts/build_map.py --input spec.json --out 输出路径.html --with-basics
```

可选校验：

```bash
python3 scripts/verify_links.py --input spec.json
```

## 公共基础 / 练习（默认内容）

**BASICS**

| 类型 | 标题 |
| --- | --- |
| 课程 | 昇腾异构编程基础（速成班） |
| 学习路径 | Ascend C编程（学习路径） |

**PRACTICE**

| 类型 | 标题 |
| --- | --- |
| 练习平台 | 算子刷题评测 · CANNJudge |
| 认证 | 算子开发者认证（入门级） |
| 检索 | 查找学习资源 |

## Resources

- `README.md` — 人读主线与社区链接总表（模型查找依据）  
- `scripts/generate.py` — 端到端出图（Agent 首选）  
- `scripts/topics.py` — `community_courses` / 类型推断  
- `scripts/build_map.py` — JSON → HTML  
- `scripts/build_blog_wall.py` — 资讯/案例墙  
- `scripts/verify_links.py` — 链接检查  
- `references/intent-map.md` — 意图映射  
- `assets/` — 头图 / 证书 / 外链图标（已内嵌进 HTML）

## 链接形态速查

| 类型 | URL 形态 |
| --- | --- |
| 课程 | `/developer/courses/detail/…` |
| 学习路径 | `/edu/growth/details/…` |
| 认证 | `/edu/developer-certification/detail/…` |
| 检索 | `/developer/edu/find-resource` |
| 练习平台 | 如 `https://cannjudge.cn` |
| 枢纽（勿当单课） | `/developer/learn` |
