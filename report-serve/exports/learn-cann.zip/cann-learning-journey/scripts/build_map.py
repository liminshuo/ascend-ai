#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build_map.py — 渲染「昇腾学习旅程地图」HTML

读取一份学习路径规格（JSON），输出与 CANN Bench 高保真原型「学习」页同款的单页 HTML：
原型头图（含标题/手绘插画/Ascend 标志）+ 学习者画像 + 竖向时间轴 + 左右交替课程卡片
+ 每卡「资源类型」标签（课程 / 学习路径 / 认证 / 练习平台 / 检索…）+ 外链图标 + 结业证书。

所有视觉元素均来自原型导出资源（assets/header.png、assets/cert.png、assets/link.svg），
以 base64 内嵌，HTML 单文件即可离线查看。

规格 JSON 结构：
{
  "title": "昇腾学习旅程地图",
  "subtitle": "按照您的技术方向，为您推荐最优的学习路径",
  "persona": {"role": "高校学生", "goal": "算子开发入门", "level": "C++"},
  "stages": [
    {
      "label": "CANN基础知识",
      "courses": [
        {"title": "…", "desc": "…", "link": "https://...", "type": "课程"},
        ...
      ]
    },
    ...
  ],
  "certificate": "获得初级证书",
  "source": "https://www.hiascend.com/developer/learn"
}

用法：
  python3 build_map.py --input spec.json --out journey.html
  cat spec.json | python3 build_map.py            # 从 stdin 读取，输出到 ./journey-map.html
"""
import argparse
import base64
import json
import os
import sys
from html import escape

HERE = os.path.dirname(os.path.abspath(__file__))
ASSETS = os.path.join(HERE, "..", "assets")


def _read_b64(name):
    p = os.path.join(ASSETS, name)
    with open(p, "rb") as f:
        return base64.b64encode(f.read()).decode("ascii")


# 资源以 base64 内嵌，保证单文件离线可用
HEADER_PNG = _read_b64("header.png")   # 原型头图：标题+手绘+ Ascend A 标志
CERT_PNG = _read_b64("cert.png")       # 原型证书图标
LINK_SVG = _read_b64("link.svg")       # 原型“打开新网页”外链图标


# ---- CANN Bench「学习」页设计 Token（从原型 FILE_DATA / 导出图提取）----
TOKENS = {
    "page_bg": "#F4F5F7",
    "card": "#FFFFFF",
    "ink": "#111421",
    "text": "#20232A",
    "muted": "#6B7280",
    "border": "#E5E7EB",
    "line": "#D1D5DB",
    "accent": "#1456F0",      # 在线体验/主色
    "accent_soft": "#E8F0FE",
    "cert": "#C7000B",
    "cert_soft": "#FDECEC",
    "pill": "#F3F4F6",
    "font": '"HarmonyHeiTi","HarmonyOS Sans SC","PingFang SC","Microsoft YaHei",sans-serif',
}


def infer_resource_type(link):
    u = (link or "").lower()
    if "cannjudge" in u:
        return "练习平台"
    if "developer-certification" in u or "/edu/certification" in u:
        return "认证"
    if "find-resource" in u:
        return "检索"
    if "/edu/growth" in u:
        return "学习路径"
    if "/courses/detail/" in u or "/edu/courses" in u:
        return "课程"
    if "/developer/learn" in u:
        return "枢纽页"
    return "资源"


def course_card(course, side):
    title = escape(str(course.get("title", "")))
    desc = escape(str(course.get("desc", "")))
    link = str(course.get("link", ""))
    rtype = str(course.get("type") or course.get("rtype") or infer_resource_type(link) or "").strip()
    pill = f'<span class="type-pill">{escape(rtype)}</span>' if rtype else ""
    # 外链图标（原型“打开新网页”）
    link_ico = f'<img class="link-ico" src="data:image/svg+xml;base64,{LINK_SVG}" alt="外链" />' if link else ""
    card_inner = f"""
      <div class="card-top">
        <div class="card-title">
          <span class="title-text">{title}</span>
          {link_ico}
        </div>
        {pill}
      </div>
      <div class="card-desc">{desc}</div>
    """
    if link:
        return f'<a class="course-card {side}" href="{escape(link)}" target="_blank" rel="noopener">{card_inner}</a>'
    return f'<div class="course-card {side}">{card_inner}</div>'


def stage_html(stage, stage_idx):
    t = TOKENS
    label = escape(str(stage.get("label", f"阶段 {stage_idx}")))
    courses = stage.get("courses", [])
    steps = []
    for i, c in enumerate(courses):
        step_num = i + 1
        side = "left" if step_num % 2 == 1 else "right"
        card = course_card(c, side)
        steps.append(f"""
        <div class="step">
          <div class="step-col col-left">{card if side=='left' else ''}</div>
          <div class="step-marker"><span class="step-num">{step_num}</span></div>
          <div class="step-col col-right">{card if side=='right' else ''}</div>
        </div>""")
    steps_html = "\n".join(steps)
    return f"""
    <section class="stage">
      <div class="stage-label-wrap"><span class="stage-label">{label}</span></div>
      <div class="stage-steps">{steps_html}
      </div>
    </section>"""


# ---- 公共「CANN 基础知识」阶段（所有主题的第一阶段，可选自动前置）----
# 三讲一实践，链接来自 quick_start/cann_basics 真实文件（文件名由 fetch_catalog.py 现抓保证最新）。
# 公共基础：卡片标题与社区落地页必须同名同义（经盘点核对）
BASICS_STAGE = {
    "label": "CANN 基础知识",
    "courses": [
        {"title": "昇腾异构编程基础（速成班）",
         "desc": "昇腾 AI 处理器硬件架构、CANN 异构计算架构入门（覆盖 NPU / CANN 基础）",
         "link": "https://www.hiascend.com/developer/courses/detail/1925466587412258817",
         "type": "课程"},
        {"title": "Ascend C编程（学习路径）",
         "desc": "Ascend C 算子开发系列路径：含异构编程基础 → 入门 / 进阶 / 高级",
         "link": "https://www.hiascend.com/edu/growth/details/9614049b0d6044c28e291aea1d931a53",
         "type": "学习路径"},
    ],
}


def render(spec):
    t = TOKENS
    title = escape(str(spec.get("title", "昇腾学习旅程地图")))
    subtitle = escape(str(spec.get("subtitle", "按照您的技术方向，为您推荐最优的学习路径")))
    persona = spec.get("persona", {})
    role = escape(str(persona.get("role", "—")))
    goal = escape(str(persona.get("goal", "—")))
    level = escape(str(persona.get("level", "—")))
    source = escape(str(spec.get("source", "https://www.hiascend.com/developer/learn")))
    cert = escape(str(spec.get("certificate", "获得初级证书")))
    cert_desc = escape(str(spec.get("cert_desc", "完成本路径全部课程与练习后可获得认证")))
    cert_url = str(spec.get("certificate_url") or "").strip()

    stage_list = list(spec.get("stages", []))
    # 公共基础阶段自动前置：spec 里显式 with_basics=true 时注入；
    # 仅当首个阶段已就是「CANN 基础知识」或显式关闭时才跳过
    with_basics = spec.get("with_basics", False)
    first_label = str(stage_list[0].get("label", "")) if stage_list else ""
    already_basics = first_label.strip() in ("CANN 基础知识", "CANN基础知识")
    if with_basics and not already_basics:
        stage_list = [dict(BASICS_STAGE)] + stage_list

    stages = [stage_html(s, i + 1) for i, s in enumerate(stage_list)]
    stages_html = "\n".join(stages)

    header_img = f"data:image/png;base64,{HEADER_PNG}"
    cert_img = f"data:image/png;base64,{CERT_PNG}"

    return f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>{title}</title>
<style>
  * {{ box-sizing: border-box; margin: 0; padding: 0; }}
  body {{
    background: {t['page_bg']};
    font-family: {t['font']};
    color: {t['text']};
    padding-bottom: 64px;
    -webkit-font-smoothing: antialiased;
  }}
  .wrap {{ max-width: 960px; margin: 0 auto; padding: 0 20px; }}

  /* ---- Header（原型头图，含标题/手绘/Ascend A）---- */
  .header {{
    position: relative;
    margin: 0 -20px;
    background:
      radial-gradient(circle at 12% 40%, rgba(255, 180, 220, .45), transparent 40%),
      radial-gradient(circle at 88% 60%, rgba(160, 220, 255, .45), transparent 40%),
      linear-gradient(90deg, #F3D9F9 0%, #E4E0FF 35%, #CCE3FF 70%, #C3F0FF 100%);
    border-bottom-left-radius: 28px;
    border-bottom-right-radius: 28px;
    overflow: hidden;
    display: flex; justify-content: center;
  }}
  .header img.header-img {{
    display: block; width: 100%; max-width: 960px; height: auto;
  }}

  /* ---- Subtitle + Profile ---- */
  .subbar {{
    margin-top: -18px;
    position: relative; z-index: 2;
    background: {t['card']};
    border: 1px solid {t['border']};
    border-radius: 20px;
    padding: 24px 28px 20px;
    box-shadow: 0 10px 34px rgba(0,0,0,.04);
  }}
  .subtitle {{
    font-size: 15px; font-weight: 500; color: {t['muted']};
    margin-bottom: 16px;
  }}
  .persona {{
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 16px;
  }}
  .chip {{
    background: {t['page_bg']}; border-radius: 12px;
    padding: 12px 16px; min-height: 68px;
    display: flex; flex-direction: column; justify-content: center;
  }}
  .chip .k {{ font-size: 12px; color: {t['muted']}; margin-bottom: 4px; }}
  .chip .v {{ font-size: 17px; font-weight: 600; color: {t['ink']}; }}

  /* ---- Timeline ---- */
  .journey {{ margin-top: 44px; position: relative; }}
  .journey::before {{
    content: "";
    position: absolute; left: 50%; top: 0; bottom: 0;
    width: 2px; background: {t['line']};
    transform: translateX(-50%);
  }}
  .stage {{ position: relative; padding-bottom: 32px; }}
  .stage:last-of-type {{ padding-bottom: 16px; }}
  .stage-label-wrap {{
    display: flex; justify-content: center;
    margin-bottom: 22px; position: relative; z-index: 1;
  }}
  .stage-label {{
    display: inline-block;
    background: {t['card']}; color: {t['ink']};
    font-size: 17px; font-weight: 600;
    padding: 9px 22px; border-radius: 999px;
    border: 1px solid {t['border']};
    box-shadow: 0 4px 14px rgba(0,0,0,.04);
  }}

  /* ---- Step / alternating cards ---- */
  .step {{
    display: flex; align-items: center; justify-content: center;
    margin-bottom: 18px; position: relative;
  }}
  .step-col {{
    flex: 1; min-width: 0;
    display: flex;
  }}
  .col-left {{ justify-content: flex-end; padding-right: 34px; }}
  .col-right {{ justify-content: flex-start; padding-left: 34px; }}
  .step-marker {{
    width: 36px; height: 36px; flex: none;
    background: {t['card']}; border: 2px solid {t['line']};
    border-radius: 50%; display: flex; align-items: center; justify-content: center;
    font-size: 15px; font-weight: 600; color: {t['ink']};
    z-index: 1;
  }}
  .course-card {{
    flex: 1; max-width: 360px; text-decoration: none; color: inherit;
    background: {t['card']}; border: 1px solid {t['border']};
    border-radius: 18px; padding: 16px 18px;
    box-shadow: 0 6px 18px rgba(0,0,0,.04);
    transition: transform .12s ease, box-shadow .12s ease, border-color .12s ease;
  }}
  .course-card:hover {{
    transform: translateY(-2px);
    box-shadow: 0 12px 28px rgba(20,86,240,.10);
    border-color: {t['accent']};
  }}
  .card-top {{ display: flex; align-items: flex-start; justify-content: space-between; gap: 10px; }}
  .card-title {{ font-size: 17px; font-weight: 600; color: {t['ink']}; line-height: 1.35;
    display: flex; align-items: flex-start; gap: 6px; }}
  .title-text {{ flex: 1; }}
  .link-ico {{ width: 15px; height: 15px; margin-top: 4px; flex: none; opacity: .55; }}
  .course-card:hover .link-ico {{ opacity: .9; }}
  .type-pill, .online-pill {{
    flex: none; font-size: 11px; font-weight: 500;
    color: {t['accent']}; background: {t['accent_soft']};
    border: 1px solid {t['accent_soft']};
    padding: 3px 8px; border-radius: 999px;
    white-space: nowrap;
  }}
  .card-desc {{ margin-top: 8px; font-size: 13px; color: {t['muted']}; line-height: 1.55; }}

  /* ---- Certificate（原型证书图标）---- */
  .cert {{
    position: relative; z-index: 1;
    margin-top: 12px; display: flex; align-items: center; gap: 16px;
    background: {t['card']}; border: 1px solid {t['border']};
    border-radius: 18px; padding: 18px 22px;
    box-shadow: 0 6px 18px rgba(0,0,0,.04);
  }}
  .cert-icon {{
    width: 52px; height: 52px; border-radius: 12px; flex: none;
    overflow: hidden; background: {t['cert_soft']};
    display: flex; align-items: center; justify-content: center;
  }}
  .cert-icon img {{ width: 100%; height: 100%; object-fit: contain; }}
  .cert-title {{ font-size: 17px; font-weight: 600; color: {t['cert']}; }}
  .cert-desc {{ margin-top: 3px; font-size: 13px; color: {t['muted']}; }}

  .foot {{ margin-top: 30px; text-align: center; font-size: 12px; color: {t['muted']}; }}
  .foot a {{ color: {t['accent']}; text-decoration: none; }}

  @media (max-width: 720px) {{
    .persona {{ grid-template-columns: 1fr; }}
    .journey::before {{ left: 18px; }}
    .step {{ display: block; padding-left: 48px; }}
    .step-marker {{ position: absolute; left: 0; top: 16px; }}
    .col-left, .col-right {{ justify-content: stretch; padding: 0; }}
    .course-card {{ max-width: 100%; }}
    .stage-label-wrap {{ justify-content: flex-start; padding-left: 48px; }}
  }}
</style>
</head>
<body>
  <header class="header">
    <img class="header-img" src="{header_img}" alt="{title}" />
  </header>

  <div class="wrap">
    <div class="subbar">
      <div class="subtitle">{subtitle}</div>
      <div class="persona">
        <div class="chip"><span class="k">角色</span><span class="v">{role}</span></div>
        <div class="chip"><span class="k">目标</span><span class="v">{goal}</span></div>
        <div class="chip"><span class="k">技术水平</span><span class="v">{level}</span></div>
      </div>
    </div>

    <div class="journey">
      {stages_html}
      <div class="cert">
        <div class="cert-icon"><img src="{cert_img}" alt="证书" /></div>
        <div>
          <div class="cert-title">{('<a href="' + escape(cert_url) + '" target="_blank" rel="noopener">' + cert + '</a>') if cert_url else cert}</div>
          <div class="cert-desc">{cert_desc}</div>
        </div>
      </div>
    </div>

    <div class="foot">
      学习资源来自昇腾社区学习中心 ·
      <a href="{source}" target="_blank" rel="noopener">{source}</a>
    </div>
  </div>
</body>
</html>"""


def main():
    ap = argparse.ArgumentParser(description="渲染昇腾学习旅程地图 HTML")
    ap.add_argument("--input", "-i", help="规格 JSON 文件路径（缺省读 stdin）")
    ap.add_argument("--out", "-o", default="journey-map.html", help="输出 HTML 路径")
    ap.add_argument("--with-basics", action="store_true",
                    help="自动前置「CANN 基础知识」公共阶段（spec 里未含基础阶段时）")
    args = ap.parse_args()

    if args.input:
        with open(args.input, encoding="utf-8") as f:
            spec = json.load(f)
    else:
        spec = json.load(sys.stdin)

    if args.with_basics:
        spec = dict(spec)
        spec["with_basics"] = True

    html = render(spec)
    with open(args.out, "w", encoding="utf-8") as f:
        f.write(html)
    print(f"OK: 已生成 {args.out}")


if __name__ == "__main__":
    main()
