#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build_blog_wall.py — 渲染「CANN 技术博客 / 实践案例墙」HTML

与技术博客（blogs/）内容对应：最新技术特性、行业动态、真实客户实践案例。
形态与学习旅程地图不同：这是「资讯/案例」，用分类卡片墙呈现（非时间轴）。

输入：fetch_catalog.py --blogs 输出的 JSON（blog 列表）
用法：
  python3 fetch_catalog.py --blogs > blogs.json
  python3 build_blog_wall.py --input blogs.json --out 博客墙.html
  # 或一步到位（内部自动抓取）
  python3 build_blog_wall.py --out 博客墙.html
"""
import argparse
import base64
import json
import os
import sys
from html import escape

HERE = os.path.dirname(os.path.abspath(__file__))
ASSETS = os.path.join(HERE, "..", "assets")


def _read_b64(name):
    with open(os.path.join(ASSETS, name), "rb") as f:
        return base64.b64encode(f.read()).decode("ascii")


HEADER_PNG = _read_b64("header.png")
LINK_SVG = _read_b64("link.svg")

TOKENS = {
    "page_bg": "#F4F5F7",
    "card": "#FFFFFF",
    "ink": "#111421",
    "text": "#20232A",
    "muted": "#6B7280",
    "border": "#E5E7EB",
    "line": "#D1D5DB",
    "accent": "#1456F0",
    "accent_soft": "#E8F0FE",
    "cert": "#C7000B",
    "pill": "#F3F4F6",
    "font": '"HarmonyHeiTi","HarmonyOS Sans SC","PingFang SC","Microsoft YaHei",sans-serif',
}

# 分类 → 主题色（卡片标签）
CATEGORY_COLORS = {
    "算子开发": ("#1456F0", "#E8F0FE"),     # 蓝
    "大模型推理": ("#7C3AED", "#F3E8FF"),   # 紫
    "大模型训练": ("#16A34A", "#DCFCE7"),   # 绿
}

CATEGORY_ORDER = ["算子开发", "大模型推理", "大模型训练"]


def _group(blogs):
    groups = {c: [] for c in CATEGORY_ORDER}
    for b in blogs:
        zh = b.get("category_zh", "算子开发")
        groups.setdefault(zh, []).append(b)
    return groups


def render(blogs, title="CANN 技术博客 · 实践案例", subtitle="最新技术特性 · 行业动态 · 真实客户实践"):
    t = TOKENS
    groups = _group(blogs)
    total = len(blogs)

    sections = []
    for cat in CATEGORY_ORDER:
        items = groups.get(cat, [])
        if not items:
            continue
        color, soft = CATEGORY_COLORS.get(cat, ("#1456F0", "#E8F0FE"))
        cards = []
        for b in items:
            btitle = escape(str(b.get("title", "")))
            bdesc = escape(str(b.get("desc", "")))
            link = str(b.get("link", ""))
            card = f"""
      <a class="blog-card" href="{escape(link)}" target="_blank" rel="noopener">
        <div class="blog-card-head">
          <span class="blog-tag" style="color:{color};background:{soft}">{escape(cat)}</span>
          <img class="link-ico" src="data:image/svg+xml;base64,{LINK_SVG}" alt="外链" />
        </div>
        <div class="blog-title">{btitle}</div>
        <div class="blog-desc">{bdesc}</div>
      </a>"""
            cards.append(card)
        section = f"""
    <section class="cat-section">
      <div class="cat-head">
        <span class="cat-dot" style="background:{color}"></span>
        <span class="cat-name">{escape(cat)}</span>
        <span class="cat-count">{len(items)} 篇</span>
      </div>
      <div class="blog-grid">{"".join(cards)}
      </div>
    </section>"""
        sections.append(section)

    header_img = f"data:image/png;base64,{HEADER_PNG}"
    body = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>{escape(title)}</title>
<style>
  * {{ box-sizing: border-box; margin: 0; padding: 0; }}
  body {{ background: {t['page_bg']}; font-family: {t['font']}; color: {t['text']};
         padding-bottom: 64px; -webkit-font-smoothing: antialiased; }}
  .wrap {{ max-width: 1080px; margin: 0 auto; padding: 0 20px; }}

  .header {{ position: relative; margin: 0 -20px; overflow: hidden;
    display: flex; justify-content: center;
    background: linear-gradient(90deg, #F3D9F9 0%, #E4E0FF 35%, #CCE3FF 70%, #C3F0FF 100%);
    border-bottom-left-radius: 28px; border-bottom-right-radius: 28px; }}
  .header img.header-img {{ display: block; width: 100%; max-width: 1080px; height: auto; }}

  .subbar {{ margin-top: -18px; position: relative; z-index: 2;
    background: {t['card']}; border: 1px solid {t['border']}; border-radius: 20px;
    padding: 22px 28px 18px; box-shadow: 0 10px 34px rgba(0,0,0,.04); }}
  .subtitle {{ font-size: 15px; font-weight: 500; color: {t['muted']}; margin-bottom: 8px; }}
  .total {{ font-size: 13px; color: {t['muted']}; }}

  .cat-section {{ margin-top: 28px; }}
  .cat-head {{ display: flex; align-items: center; gap: 8px; margin-bottom: 14px; }}
  .cat-dot {{ width: 10px; height: 10px; border-radius: 50%; }}
  .cat-name {{ font-size: 18px; font-weight: 600; color: {t['ink']}; }}
  .cat-count {{ font-size: 13px; color: {t['muted']}; }}

  .blog-grid {{ display: grid; grid-template-columns: repeat(2, 1fr); gap: 16px; }}
  .blog-card {{ display: flex; flex-direction: column; text-decoration: none; color: inherit;
    background: {t['card']}; border: 1px solid {t['border']}; border-radius: 16px;
    padding: 16px 18px; box-shadow: 0 6px 18px rgba(0,0,0,.04);
    transition: transform .12s ease, box-shadow .12s ease, border-color .12s ease; }}
  .blog-card:hover {{ transform: translateY(-2px);
    box-shadow: 0 12px 28px rgba(20,86,240,.10); border-color: {t['accent']}; }}
  .blog-card-head {{ display: flex; align-items: center; justify-content: space-between; }}
  .blog-tag {{ font-size: 12px; font-weight: 500; padding: 3px 10px; border-radius: 999px; }}
  .link-ico {{ width: 15px; height: 15px; opacity: .5; }}
  .blog-card:hover .link-ico {{ opacity: .9; }}
  .blog-title {{ margin-top: 10px; font-size: 16px; font-weight: 600; color: {t['ink']}; line-height: 1.4; }}
  .blog-desc {{ margin-top: 8px; font-size: 13px; color: {t['muted']}; line-height: 1.6;
    display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden; }}

  .foot {{ margin-top: 30px; text-align: center; font-size: 12px; color: {t['muted']}; }}
  .foot a {{ color: {t['accent']}; text-decoration: none; }}

  @media (max-width: 720px) {{ .blog-grid {{ grid-template-columns: 1fr; }} }}
</style>
</head>
<body>
  <header class="header"><img class="header-img" src="{header_img}" alt="{escape(title)}" /></header>
  <div class="wrap">
    <div class="subbar">
      <div class="subtitle">{escape(subtitle)}</div>
      <div class="total">共 {total} 篇，来自 CANN 学习中心技术博客，持续更新</div>
    </div>
    {"".join(sections)}
    <div class="foot">
      内容来自 CANN 学习中心 · <a href="https://gitcode.com/cann/cann-learning-hub/tree/master/blogs" target="_blank" rel="noopener">blogs/</a>
    </div>
  </div>
</body>
</html>"""
    return body


def main():
    ap = argparse.ArgumentParser(description="渲染 CANN 技术博客墙 HTML")
    ap.add_argument("--input", "-i", help="fetch_catalog --blogs 输出的 JSON（缺省自动抓取）")
    ap.add_argument("--out", "-o", default="blog-wall.html", help="输出 HTML 路径")
    ap.add_argument("--refresh", action="store_true", help="抓取时强制更新仓库缓存")
    args = ap.parse_args()

    if args.input:
        with open(args.input, encoding="utf-8") as f:
            blogs = json.load(f)
    else:
        import tempfile
        import fetch_catalog
        cache = os.path.join(tempfile.gettempdir(), "cann-journey-cache")
        repo = fetch_catalog._ensure_repo(cache, args.refresh)
        blogs = fetch_catalog.list_blogs(repo)

    html = render(blogs)
    with open(args.out, "w", encoding="utf-8") as f:
        f.write(html)
    print(f"OK: 已生成 {args.out}（共 {len(blogs)} 篇）")


if __name__ == "__main__":
    main()
