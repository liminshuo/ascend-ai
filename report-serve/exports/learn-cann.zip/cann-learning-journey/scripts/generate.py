#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
generate.py — 端到端生成学习旅程地图（第 3 层：一句「学通信」直接出图）

接收「主题 key + 画像」，内部自动完成：
  抓目录(fetch_catalog) → 按章节分组 → 组装 spec → 注入基础阶段 → 渲染(build_map)
无需手写 spec，仓库更新时抓出来的就是最新课程。

用法：
  python3 generate.py --topic comm --out 输出.html
  python3 generate.py --topic graph --role "开发人员" --level "Python" --out 图框架.html
  python3 generate.py --topic pyasc --goal "用 Python 写算子" --no-practice   # 去掉练习阶段

主题 key（11 个）：
  operator / inference / training / recommend / basics / application /
  graph / comm / pyasc / cannbot / ai_app
"""
import argparse
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import topics
from fetch_catalog import build_courses, _ensure_repo

TITLE = "昇腾学习旅程地图"
SUBTITLE = "按照您的技术方向，为您推荐最优的学习路径"
SOURCE = "https://www.hiascend.com/developer/learn"


def _build_stage(label, courses):
    # 去掉内部字段 _file/_chapter，保留标准字段
    cleaned = []
    for c in courses:
        cleaned.append({k: v for k, v in c.items() if not k.startswith("_")})
    return {"label": label, "courses": cleaned}


def _group_by_chapter(courses):
    """把课程按 _chapter 分组，返回 [(chapter, [course...]), ...]，保持章节出现顺序。"""
    order, buckets = [], {}
    for c in courses:
        ch = c.get("_chapter") or "(未分组)"
        if ch not in buckets:
            buckets[ch] = []
            order.append(ch)
        buckets[ch].append(c)
    return [(ch, buckets[ch]) for ch in order]


def generate(topic_key, role=None, goal=None, level=None,
             with_practice=True, cache=None, refresh=False):
    topic = topics.get_topic(topic_key)
    if cache is None:
        import tempfile
        cache = os.path.join(tempfile.gettempdir(), "cann-journey-cache")
    repo = _ensure_repo(cache, refresh)

    stages = []
    for st in topic["stages"]:
        label = st["label"]
        # 优先用社区真名+真链卡片，保证标题与落地页一致
        curated = st.get("community_courses")
        if curated:
            stages.append(_build_stage(label, curated))
            continue
        stage_community = st.get("community")
        all_courses = []
        for d in st.get("dirs") or []:
            try:
                raw = build_courses(d, repo)
                all_courses.extend(
                    topics.apply_community_links(raw, rel_dir=d, stage_community=stage_community)
                )
            except Exception as e:
                print(f"[warn] 抓取 {d} 失败: {e}", file=sys.stderr)
        stages.append(_build_stage(label, all_courses))

    if with_practice:
        stages.append(topics.PRACTICE_STAGE)

    persona = {
        "role": role or topics.DEFAULT_ROLE,
        "goal": goal or topic["goal"],
        "level": level or topic["level"],
    }
    spec = {
        "title": TITLE,
        "subtitle": SUBTITLE,
        "persona": persona,
        "stages": stages,
        "certificate": topic["certificate"],
        "cert_desc": "完成本路径全部课程与练习后可获得认证",
        "certificate_url": topic.get("certificate_url") or topics.COMMUNITY_CERT,
        "source": SOURCE,
        "with_basics": True,   # 由 build_map 自动前置「CANN 基础知识」
    }
    return spec


def main():
    ap = argparse.ArgumentParser(description="端到端生成学习旅程地图")
    ap.add_argument("--topic", "-t", required=True,
                    help="主题 key：" + "/".join(sorted(topics.TOPICS)))
    ap.add_argument("--role", help="画像·角色（缺省：开发人员）")
    ap.add_argument("--goal", help="画像·目标（缺省：主题默认）")
    ap.add_argument("--level", help="画像·技术水平（缺省：主题默认）")
    ap.add_argument("--out", "-o", required=True, help="输出 HTML 路径")
    ap.add_argument("--no-practice", action="store_true", help="不追加「练习与在线体验」阶段")
    ap.add_argument("--spec-out", help="（可选）同时把组装好的 spec 存成 JSON，便于调试")
    ap.add_argument("--cache", help="fetch_catalog 缓存目录（缺省系统临时目录）")
    ap.add_argument("--refresh", action="store_true", help="强制 git pull 更新仓库缓存")
    args = ap.parse_args()

    spec = generate(args.topic, role=args.role, goal=args.goal, level=args.level,
                    with_practice=not args.no_practice,
                    cache=args.cache, refresh=args.refresh)

    if args.spec_out:
        with open(args.spec_out, "w", encoding="utf-8") as f:
            json.dump(spec, f, ensure_ascii=False, indent=2)
        print(f"spec 已存 {args.spec_out}")

    # 调 build_map 渲染
    import build_map
    html = build_map.render(spec)
    with open(args.out, "w", encoding="utf-8") as f:
        f.write(html)
    print(f"OK: 已生成 {args.out}")


if __name__ == "__main__":
    main()
