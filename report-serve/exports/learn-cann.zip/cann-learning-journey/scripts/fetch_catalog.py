#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
fetch_catalog.py — 可靠抓取 CANN 学习中心仓库的实时目录（列出真实 notebook 文件名）

解决的问题：GitCode 的 tree/blob 页面对不存在的路径也返回 200（SPA 兜底页），
且部分新目录（图框架/通信/PyASC/PyPTO 等）的目录页只渲染最近 commit、不返回文件清单，
导致 WebFetch 拿不到真实文件名。

方案：用 git 的 sparse-checkout（浅克隆 + 不下载 blob）直接拉取目标目录的树，
再用 find 列出真实文件名 —— 这是唯一稳定可靠的来源，结果是「真实存在的文件」而非猜测。

用法：
  # 列出单个目录下的所有 notebook（输出 JSON）
  python3 fetch_catalog.py --dirs tutorials/pyasc_operator_development

  # 一次列多个目录
  python3 fetch_catalog.py --dirs tutorials/ge_development tutorials/TorchAir_development

  # 输出为 markdown 清单（人类可读）
  python3 fetch_catalog.py --dirs tutorials/pyasc_operator_development --format md

  # 返回「目录 -> 课程卡 list」的 JSON（供 build_map.py 或模型直接消费）
  python3 fetch_catalog.py --dirs tutorials/ge_development --as-courses

机制：
  - 首次克隆到 --cache 目录（默认系统临时目录），后续复用（git pull 增量更新）。
  - --depth 1 --filter=blob:none 只拉树不拉文件内容，速度快。
  - 克隆/拉取失败时输出 JSON 错误对象（exit 非零），绝不返回猜测数据。
"""
import argparse
import json
import os
import subprocess
import sys
import tempfile

REPO_URL = "https://gitcode.com/cann/cann-learning-hub.git"
BLOB_BASE = "https://gitcode.com/cann/cann-learning-hub/blob/master/"
TREE_BASE = "https://gitcode.com/cann/cann-learning-hub/tree/master/"

# 占位章节（不当作「课程」）：章介绍/章练习/章测试/答案
_SKIP_PATTERNS = (
    "chapter_intro", "chapter_practice", "chapter_test",
    "chapter_summary", "answer", "readme",
)

# 文件名关键词 → 中文（用于把英文文件名转成可读中文标题）
# 命中即替换；按词长降序匹配，先长后短避免误伤。覆盖不到时保留原文（不硬翻）。
_TITLE_ZH = {
    # 章节前缀（通常出现在路径里，用于分层）
    "basic_concepts": "基础概念", "basic_overview": "基础概览", "quick_start": "快速上手",
    "common_features": "常用特性", "advanced_features": "高级特性",
    "practice_and_debug": "实践与调试", "practice_and_troubleshooting": "实践与排查",
    "troubleshooting": "问题排查", "perf_optimization": "性能优化", "performance_optimization": "性能优化",
    # 通用词
    "chapter": "章节", "intro": "入门", "overview": "概览", "introduction": "简介",
    "practice": "实践", "exercise": "练习", "example": "示例", "demo": "示例",
    "development": "开发", "basic": "基础", "advanced": "进阶", "intermediate": "中级",
    "kernel": "核函数", "function": "函数", "operator": "算子", "operators": "算子",
    "matmul": "矩阵乘", "matrix": "矩阵", "vector": "矢量", "cube": "Cube",
    "tiling": "Tiling", "fused": "融合", "fusion": "融合", "elementwise": "逐元素",
    "reduction": "规约", "softmax": "Softmax", "normalization": "归一化", "attention": "注意力",
    "transformer": "Transformer", "controlflow": "控制流", "dynamic_shape": "动态形状",
    "inplace": "原地", "memory_reuse": "内存复用", "multi_stream": "多流", "core_limit": "核限制",
    "compile": "编译", "compilation": "编译", "cache": "缓存",
    # HCCL / 通信
    "cluster": "集群", "collective": "集合", "comm": "通信", "communication": "通信",
    "algorithm": "算法", "algorithms": "算法", "bandwidth": "带宽",
    "allreduce": "AllReduce", "allgather": "AllGather", "reduce_scatter": "ReduceScatter",
    "one_sided": "单边", "one": "单", "sided": "边",
    "resource_management": "资源管理", "resource": "资源", "management": "管理",
    "memory_management": "内存管理", "memory": "内存",
    "link_management": "链路管理", "link": "链路",
    "data_transfer": "数据传输", "transfer": "传输", "data": "数据",
    "transfer_mode": "传输模式", "mode": "模式",
    "direct": "直传", "buffer": "缓冲", "fabricmem": "FabricMem",
    "pd_separation": "PD 分离", "separation": "分离",
    "kv_cache": "KV Cache", "kv": "KV", "pooling": "池化",
    "mooncake": "Mooncake", "datadist": "DataDist", "store": "存储",
    "cloud": "云", "pack": "包", "setup": "配置", "test": "测试", "cases": "案例",
    "configure": "配置", "debug": "调试", "verify": "验证", "appendix": "附录",
    "local": "本地", "env": "环境", "first": "第一个", "flow": "流程",
    "concepts": "概念", "concept": "概念", "typical": "典型", "issue": "问题",
    "troubleshoot": "排查", "analysis": "分析", "performance": "性能",
    # LLM / 推理
    "inference": "推理", "quantization": "量化", "profiling": "性能分析", "profile": "分析",
    "bottleneck": "瓶颈", "llm": "大模型", "qwen": "Qwen", "decode": "解码", "prefill": "预填充",
    # 训练
    "sft": "SFT", "rl": "RL", "training": "训练", "pipeline": "流水线", "fine_tuning": "微调",
    # 应用
    "rag": "RAG", "knowledge_base": "知识库", "recommend": "推荐", "deepfm": "DeepFM",
    # 基础课
    "ai": "人工智能", "basics": "基础", "npu": "NPU", "cann": "CANN",
    "what_is": "什么是", "what": "什么是", "hello": "Hello", "world": "World",
}


def _zh_title(keyword):
    """单个词条的中文翻译，查不到返回 None。"""
    return _TITLE_ZH.get(keyword)


def _translate_title(raw_title):
    """把英文文件名标题翻译成中文（命中词典，未命中保留原文）。

    raw_title 是「下划线分隔」的原始串（未替换空格）。
    策略：按 _ 切成 token；对相邻 token 尝试更长词组优先匹配（如 what_is -> 什么是）。
    命中则替换，未命中保留原文，保证不硬翻、不丢信息。
    """
    tokens = raw_title.split("_")
    out = []
    i = 0
    while i < len(tokens):
        tok = tokens[i]
        # 尝试最长词组匹配（从当前 token 起，向后拼 3..2 个 token 查词典）
        matched = None
        for span in (3, 2):
            if i + span <= len(tokens):
                phrase = "_".join(tokens[i:i + span])
                if phrase in _TITLE_ZH:
                    matched = _TITLE_ZH[phrase]
                    i += span
                    break
        if matched is not None:
            out.append(matched)
            continue
        # 单 token 匹配
        out.append(_TITLE_ZH.get(tok, tok))
        i += 1

    # 拼接：相邻两个结果都含中文时直接连写（中文无需空格分隔），否则加空格
    def _is_cjk(s):
        return any("\u4e00" <= ch <= "\u9fff" for ch in s)
    zh = ""
    for idx, w in enumerate(out):
        if idx > 0:
            prev_cjk = _is_cjk(out[idx - 1])
            cur_cjk = _is_cjk(w)
            zh += "" if (prev_cjk and cur_cjk) else " "
        zh += w
    return zh


def _sh(cmd, **kw):
    return subprocess.run(cmd, capture_output=True, text=True, **kw)


def _ensure_repo(cache_dir, refresh):
    """克隆或更新仓库（浅克隆 + 不拉 blob），返回 repo 根路径。"""
    repo = os.path.join(cache_dir, "cann-learning-hub")
    if os.path.isdir(os.path.join(repo, ".git")):
        if refresh:
            _sh(["git", "-C", repo, "pull", "--ff-only", "--depth", "1"],
                timeout=120)
        return repo
    os.makedirs(cache_dir, exist_ok=True)
    r = _sh(["git", "clone", "--depth", "1", "--filter=blob:none", "--sparse",
             REPO_URL, repo], timeout=300)
    if r.returncode != 0:
        raise RuntimeError("git clone 失败: " + (r.stderr or r.stdout).strip()[:300])
    return repo


def _list_dir(repo, rel_dir):
    """sparse-checkout 某目录后用 find 列出 .ipynb / .md 真实文件名。"""
    r = _sh(["git", "-C", repo, "sparse-checkout", "set", rel_dir], timeout=120)
    if r.returncode != 0:
        raise RuntimeError(f"sparse-checkout '{rel_dir}' 失败: "
                           + (r.stderr or r.stdout).strip()[:300])
    out = _sh(["git", "-C", repo, "ls-files", rel_dir], timeout=60)
    if out.returncode != 0:
        raise RuntimeError(f"ls-files '{rel_dir}' 失败: "
                           + (out.stderr or out.stdout).strip()[:300])
    files = [l for l in out.stdout.splitlines() if l.strip()]
    return files


def _classify(files, rel_dir=""):
    """把文件列表分类为 notebooks / 文档 / 其他，并识别目录层级。"""
    notebooks, docs, others = [], [], []
    prefix = rel_dir.rstrip("/") + "/"
    for f in files:
        if f.endswith(".ipynb"):
            notebooks.append(f)
        elif f.endswith(".md"):
            docs.append(f)
        else:
            others.append(f)
    # 提取相对 rel_dir 的第一层子目录
    subdirs = set()
    for f in files:
        rel = f[len(prefix):] if f.startswith(prefix) else f
        if "/" in rel:
            subdirs.add(rel.split("/")[0])
    return notebooks, docs, others, sorted(subdirs)


def _is_course(fname):
    """判断一个 notebook 是否是「课程」而非占位章/答案。"""
    low = fname.lower()
    return not any(p in low for p in _SKIP_PATTERNS)


def _course_title(fname):
    """从文件名生成可读中文标题（去掉数字前缀，命中词典则翻译）。"""
    base = os.path.basename(fname)
    base = base[:-6] if base.endswith(".ipynb") else base
    # 去掉形如 01.02_ / 02_ 的数字前缀
    parts = base.split("_", 1)
    if parts and parts[0].replace(".", "").isdigit():
        base = parts[1] if len(parts) > 1 else base
    return _translate_title(base)


def _chapter_of(fname, rel_dir):
    """从路径提取章节归属（相对 rel_dir 的第一层子目录）。"""
    prefix = rel_dir.rstrip("/") + "/"
    rel = fname[len(prefix):] if fname.startswith(prefix) else fname
    if "/" in rel:
        return rel.split("/")[0]
    return ""


def build_courses(rel_dir, repo):
    """把某目录下的真实文件转成课程卡列表（title + link + 等级字段）。"""
    files = _list_dir(repo, rel_dir)
    notebooks, docs, _, _ = _classify(files, rel_dir=rel_dir)
    courses = []
    for n in sorted(notebooks):
        if not _is_course(n):
            continue
        title = _course_title(n)
        courses.append({
            "title": title,
            "desc": "",
            "link": BLOB_BASE + n,
            "online": True,
            "_file": n,
            "_chapter": _chapter_of(n, rel_dir),
        })
    # 无 notebook 课程时，把 .md 也纳入兜底
    if not courses:
        for d in sorted(docs):
            courses.append({
                "title": _course_title(d),
                "desc": "",
                "link": BLOB_BASE + d,
                "online": True,
                "_file": d,
                "_chapter": _chapter_of(d, rel_dir),
            })
    return courses


def _read_md_title_desc(abs_path, max_desc=160):
    """读博客 md 的第一行标题（# 开头）与摘要。

    优先取「标题之后、第一个 ## 之前」的连续正文；
    若该区间为空（标题后直接跟 ##），退化为取第一个 ## 之后的段首（跳过 ## 行与图片行）。
    """
    title, desc = "", ""
    try:
        with open(abs_path, encoding="utf-8") as f:
            text = f.read()
    except Exception:
        return None, None
    lines = text.splitlines()
    # 标题：第一个 # 行
    for l in lines:
        s = l.strip()
        if s.startswith("# ") and not s.startswith("## "):
            title = s[2:].strip()
            break

    def clean(s):
        s = s.strip().lstrip(">").strip()
        return s

    # 方案 A：标题行之后、第一个 ## 之前的正文
    body_started = False
    buf = []
    for l in lines:
        s = l.strip()
        if s.startswith("## "):
            break
        if not body_started:
            if s.startswith("# ") and not s.startswith("## "):
                body_started = True
            continue
        if s and not s.startswith("![") and not s.startswith("http"):
            buf.append(clean(s))
    desc = " ".join(buf).strip()

    # 方案 B：若为空，取第一个 ## 之后的段首文字
    if not desc:
        in_body = False
        buf2 = []
        for l in lines:
            s = l.strip()
            if s.startswith("## ") and not in_body:
                in_body = True
                continue
            if in_body:
                if s.startswith("## "):
                    break
                if s and not s.startswith("![") and not s.startswith("http"):
                    buf2.append(clean(s))
                if buf2 and len(" ".join(buf2)) > 40:
                    break
        desc = " ".join(buf2).strip()

    if len(desc) > max_desc:
        desc = desc[:max_desc].rstrip() + "…"
    return title, desc


def list_blogs(repo, rel_dir="blogs"):
    """抓 blogs 目录下的技术博客，返回分类列表。

    返回 [{ "category": "inference"|"operator"|"training", "title": 真实中文标题, "desc": 摘要, "link": blob链接, "_file": 相对路径 }]
    标题/摘要直接读 md 文件（博客自带中文标题，不用词典翻译）。
    """
    files = _list_dir(repo, rel_dir)
    blogs = []
    categories = {"inference": "大模型推理", "operator": "算子开发", "training": "大模型训练"}
    for f in sorted(files):
        if not f.endswith(".md"):
            continue
        parts = f.split("/")
        # 结构：blogs/<category>/<slug>/<slug>.md
        if len(parts) < 3:
            continue
        cat = parts[1]
        if cat not in categories:
            cat = "其他"
        slug = parts[-2] if len(parts) >= 3 else ""
        abs_path = os.path.join(repo, f)
        title, desc = _read_md_title_desc(abs_path)
        if not title:
            title = slug.replace("_", " ").replace("-", " ")
        blogs.append({
            "category": cat,
            "category_zh": categories.get(cat, cat),
            "title": title,
            "desc": desc or "",
            "link": BLOB_BASE + f,
            "online": True,
            "_file": f,
        })
    return blogs


def main():
    ap = argparse.ArgumentParser(description="抓取 CANN 学习中心仓库真实目录")
    ap.add_argument("--dirs", nargs="+",
                    help="要抓的仓库内目录路径（如 tutorials/pyasc_operator_development；--blogs 模式可省略）")
    ap.add_argument("--format", choices=["json", "md"], default="json")
    ap.add_argument("--cache", default=os.path.join(tempfile.gettempdir(), "cann-journey-cache"))
    ap.add_argument("--refresh", action="store_true", help="强制 git pull 更新缓存")
    ap.add_argument("--as-courses", action="store_true",
                    help="输出「目录 -> 课程卡列表」，可直接供 build_map.py 消费")
    ap.add_argument("--blogs", action="store_true",
                    help="抓取 blogs 目录下的技术博客（标题+摘要+分类），供博客墙渲染")
    args = ap.parse_args()

    try:
        repo = _ensure_repo(args.cache, args.refresh)
    except Exception as e:
        print(json.dumps({"error": str(e)}, ensure_ascii=False))
        sys.exit(1)

    if args.blogs:
        blogs = list_blogs(repo)
        print(json.dumps(blogs, ensure_ascii=False, indent=2))
        return

    if not args.dirs:
        print(json.dumps({"error": "请提供 --dirs 或使用 --blogs"}, ensure_ascii=False))
        sys.exit(1)

    result = {}
    for d in args.dirs:
        try:
            notebooks, docs, others, dirs = _classify(_list_dir(repo, d), rel_dir=d)
            if args.as_courses:
                result[d] = build_courses(d, repo)
            else:
                result[d] = {
                    "notebooks": sorted(notebooks),
                    "docs": sorted(docs),
                    "other_count": len(others),
                    "subdirs": dirs,
                }
        except Exception as e:
            result[d] = {"error": str(e)}

    if args.format == "md":
        for d, info in result.items():
            print(f"\n## {d}")
            if "error" in info:
                print(f"  ❌ {info['error']}")
                continue
            if args.as_courses:
                for c in info:
                    print(f"  - [{c['title']}]({c['link']})")
            else:
                print(f"  子目录: {', '.join(info['subdirs'])}")
                for n in info["notebooks"]:
                    print(f"  - {n}")
                for m in info["docs"]:
                    print(f"  - {m} (md)")
    else:
        print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()