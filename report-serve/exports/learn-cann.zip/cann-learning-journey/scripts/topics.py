# -*- coding: utf-8 -*-
"""
topics.py — 主题 → 目录锚点 与 阶段骨架（数据层，供 generate.py 使用）

规则：
  - dirs：仍用于 fetch_catalog 抓仓库课表（结构参考）
  - community_courses：旅程地图**对外展示**的卡片（标题 = 社区资源真名，link = 社区真链）
    有 community_courses 时，生成 HTML 以它为准，避免「Notebook 标题 ↔ 社区详情页」错挂
  - 无 community_courses 时，才回退到抓取课表 + DIR_COMMUNITY 改写 link（可能一对多）
"""

COMMUNITY_HOME = "https://www.hiascend.com/developer/learn"
COMMUNITY_FIND = "https://www.hiascend.com/developer/edu/find-resource"
COMMUNITY_COURSES = "https://www.hiascend.com/edu/courses"
COMMUNITY_CERT = "https://www.hiascend.com/edu/certification"

# 目录 → 社区真链（仅作无 community_courses 时的回退）
DIR_COMMUNITY = {
    "quick_start/cann_basics":
        "https://www.hiascend.com/developer/courses/detail/1925466587412258817",
    "quick_start/first_custom_operator":
        "https://www.hiascend.com/developer/courses/detail/1691696509765107713",
    "tutorials/ascendc_operator_development":
        "https://www.hiascend.com/edu/growth/details/9614049b0d6044c28e291aea1d931a53",
    "tutorials/ascendc_operator_development_light":
        "https://www.hiascend.com/edu/growth/details/9614049b0d6044c28e291aea1d931a53",
    "quick_start/first_llm_inference":
        "https://www.hiascend.com/edu/growth/details/6bc86a3877c442308d6a92079765d899",
    "tutorials/llm_inference":
        "https://www.hiascend.com/edu/growth/details/6bc86a3877c442308d6a92079765d899",
    "tutorials/ge_development":
        "https://www.hiascend.com/edu/growth/details/c4ef987e0ae04fa3a3846c573c4766da",
    "tutorials/autofusion_development":
        "https://www.hiascend.com/edu/growth/details/c4ef987e0ae04fa3a3846c573c4766da",
    "tutorials/TorchAir_development":
        "https://www.hiascend.com/edu/growth/details/c4ef987e0ae04fa3a3846c573c4766da",
    "contrib/tutorials/swanlab_examples":
        "https://www.hiascend.com/edu/growth/details/785809de8b7a47d496e2acbb992f7858",
    "tutorials/sft_training_pipeline":
        "https://www.hiascend.com/edu/growth/details/f81218a9cc1641fa8ca1467651da1418",
    "tutorials/rl_training_pipeline":
        "https://www.hiascend.com/developer/courses/detail/2013153653191442434",
    "contrib/tutorials/torch-rechub":
        "https://www.hiascend.com/developer/courses/detail/1906525736459960321",
    "reference_practice/yolov13_offline_inference":
        "https://www.hiascend.com/edu/growth/details/d1c1ac12e6284557a0230ba6ebb4ddc1",
    "tutorials/hccl_development":
        "https://www.hiascend.com/edu/growth/details/e73027aabc0a4e01a0ee3692b63474a3",
    "tutorials/hixl_development":
        "https://www.hiascend.com/edu/growth/details/e73027aabc0a4e01a0ee3692b63474a3",
    "tutorials/pyasc_operator_development":
        "https://www.hiascend.com/edu/growth/details/40da2182f5c94d4c9ddb2b582161e0f5",
    "tutorials/pypto_development":
        "https://www.hiascend.com/developer/courses/detail/1998217338603737090",
    "tutorials/CANNBot":
        "https://www.hiascend.com/edu/growth/details/9614049b0d6044c28e291aea1d931a53",
    "reference_practice/ai_application_development":
        "https://www.hiascend.com/edu/growth/details/d75ff158fb3046e087440a47745b40f1",
}


def infer_resource_type(link):
    """按社区 URL 形态推断资源类型（可被 _cc 显式 type 覆盖）。"""
    u = (link or "").lower()
    if "cannjudge" in u:
        return "练习平台"
    if "developer-certification" in u or "/edu/certification" in u:
        return "认证"
    if "find-resource" in u:
        return "检索"
    if "/edu/growth" in u:
        return "学习路径"
    if "/courses/detail/" in u or "/edu/courses" in u:
        return "课程"
    if "/developer/learn" in u:
        return "枢纽页"
    return "资源"


def _cc(title, link, desc, rtype=None, online=True):
    return {
        "title": title,
        "desc": desc,
        "link": link,
        "type": rtype or infer_resource_type(link),
        "online": online,
    }


TOPICS = {
    "operator": {
        "goal": "算子开发入门", "level": "C++",
        "stages": [
            {
                "label": "算子开发入门",
                "dirs": ["quick_start/first_custom_operator"],
                "community": "https://www.hiascend.com/developer/courses/detail/1691696509765107713",
                "community_courses": [
                    _cc("Ascend C算子开发（入门）",
                        "https://www.hiascend.com/developer/courses/detail/1691696509765107713",
                        "Ascend C 入门：自定义算子编写、编译与调用全流程"),
                ],
            },
            {
                "label": "Ascend C 算子开发",
                "dirs": ["tutorials/ascendc_operator_development"],
                "community": "https://www.hiascend.com/edu/growth/details/9614049b0d6044c28e291aea1d931a53",
                "community_courses": [
                    _cc("Ascend C算子开发（进阶）",
                        "https://www.hiascend.com/developer/courses/detail/1696414606799486977",
                        "Vector/Cube、编程范式与进阶算子开发"),
                    _cc("Ascend C算子开发（高级）",
                        "https://www.hiascend.com/developer/courses/detail/1696690858236694530",
                        "工程化开发、融合算子与高级实践"),
                    _cc("Ascend C Skills 全景概览",
                        "https://www.hiascend.com/developer/courses/detail/2056647289996673026",
                        "Ascend C Skills 能力与课程全景"),
                    _cc("MindStudio实战精讲-算子调试工具",
                        "https://www.hiascend.com/developer/courses/detail/2046763915643473921",
                        "算子调试工具链实操"),
                    _cc("MindStudio实战精讲-算子调优工具",
                        "https://www.hiascend.com/developer/courses/detail/2046475214141014018",
                        "算子性能调优工具实操"),
                    _cc("GEMM类算子调优",
                        "https://www.hiascend.com/developer/courses/detail/1925473416036966402",
                        "GEMM 类算子性能调优实践"),
                ],
            },
        ],
        "practice_dir": None,
        "certificate": "算子开发者认证（入门级）",
        "certificate_url": "https://www.hiascend.com/edu/developer-certification/detail/3a0544a46aad4d588630c15bc83f2ee9",
    },
    "inference": {
        "goal": "大模型推理开发", "level": "Python",
        "stages": [
            {
                "label": "大模型推理入门",
                "dirs": ["quick_start/first_llm_inference"],
                "community_courses": [
                    _cc("文本生成推理（学习路径）",
                        "https://www.hiascend.com/edu/growth/details/6bc86a3877c442308d6a92079765d899",
                        "文本生成推理入门与实践路径"),
                    _cc("vLLM-Ascend推理部署及模型迁移适配",
                        "https://www.hiascend.com/developer/courses/detail/2071428481241497602",
                        "vLLM-Ascend 部署与模型迁移"),
                ],
            },
            {
                "label": "大模型推理系列课程",
                "dirs": ["tutorials/llm_inference"],
                "community_courses": [
                    _cc("基于vllm-ascend的profiling采集及推理profiling性能分析",
                        "https://www.hiascend.com/developer/courses/detail/2060174102022684674",
                        "推理 Profiling 采集与性能分析"),
                    _cc("模型量化压缩（学习路径）",
                        "https://www.hiascend.com/edu/growth/details/4a0ce7932c534d42816b6fa3b8ff4dbc",
                        "大模型量化压缩路径"),
                    _cc("推理性能调优（学习路径）",
                        "https://www.hiascend.com/edu/growth/details/e73ec56894914c64bd0285101955e58b",
                        "推理性能调优路径"),
                ],
            },
            {
                "label": "推理部署与优化",
                "dirs": ["tutorials/ge_development", "tutorials/autofusion_development"],
                "community_courses": [
                    _cc("推理引擎（学习路径）",
                        "https://www.hiascend.com/edu/growth/details/c4ef987e0ae04fa3a3846c573c4766da",
                        "GE / 图模式等推理引擎路径"),
                    _cc("多机多卡并行推理（学习路径）",
                        "https://www.hiascend.com/edu/growth/details/4e9c703842904f28b1289ae3e259e94a",
                        "多机多卡并行推理路径"),
                    _cc("LLM多机多卡并行推理",
                        "https://www.hiascend.com/developer/courses/detail/2004093014389059585",
                        "LLM 多机多卡并行推理课程"),
                ],
            },
        ],
        "certificate": "获得大模型推理开发证书",
        "certificate_url": "https://www.hiascend.com/edu/developer-certification/detail/a2a114ff736e4e3eaae4e09b2caea8e9",
    },
    "training": {
        "goal": "大模型训练开发", "level": "Python",
        "stages": [
            {
                "label": "微调实战案例（SwanLab）",
                "dirs": ["contrib/tutorials/swanlab_examples"],
                "community_courses": [
                    _cc("LLM 后训练（学习路径）",
                        "https://www.hiascend.com/edu/growth/details/785809de8b7a47d496e2acbb992f7858",
                        "LLM 后训练 / 微调路径"),
                    _cc("LLM微调（学习路径）",
                        "https://www.hiascend.com/edu/growth/details/85a0535925534e73a8416e3d0cda65e2",
                        "LLM 微调路径"),
                ],
            },
            {
                "label": "SFT/RL 初阶与中阶",
                "dirs": ["tutorials/sft_training_pipeline", "tutorials/rl_training_pipeline"],
                "community_courses": [
                    _cc("大语言模型训练（学习路径）",
                        "https://www.hiascend.com/edu/growth/details/f81218a9cc1641fa8ca1467651da1418",
                        "大语言模型训练路径"),
                    _cc("MindSpeed大模型训练全流程（速成班）",
                        "https://www.hiascend.com/developer/courses/detail/1998643482066972673",
                        "MindSpeed 训练全流程速成"),
                    _cc("MindSpeed RL强化学习全流程",
                        "https://www.hiascend.com/developer/courses/detail/2013153653191442434",
                        "MindSpeed RL 强化学习全流程"),
                    _cc("【先锋计划】verl强化学习全流程",
                        "https://www.hiascend.com/developer/courses/detail/2071849100282081282",
                        "verl 强化学习全流程"),
                ],
            },
        ],
        "certificate": "获得训练实践证书",
        "certificate_url": "https://www.hiascend.com/edu/developer-certification/detail/d49a9915599e49be8e978db5dce42d88",
    },
    "recommend": {
        "goal": "推荐系统开发", "level": "Python",
        "stages": [
            {
                "label": "推荐系统开发",
                "dirs": ["contrib/tutorials/torch-rechub"],
                "community_courses": [
                    _cc("认识安装Rec SDK",
                        "https://www.hiascend.com/developer/courses/detail/1906524655197753346",
                        "Rec SDK 认识与安装"),
                    _cc("如何利用Rec SDK完成推荐模型训练（little demo）",
                        "https://www.hiascend.com/developer/courses/detail/1906525736459960321",
                        "Rec SDK 推荐模型训练小实验"),
                    _cc("Mindx-RecSDK架构及特性解读",
                        "https://www.hiascend.com/developer/courses/detail/2009234890159132674",
                        "RecSDK 架构与特性"),
                ],
            },
        ],
        "certificate": "获得推荐系统开发证书",
        "certificate_url": COMMUNITY_CERT,
    },
    "basics": {
        "goal": "CANN 基础入门", "level": "入门",
        "stages": [
            {
                "label": "CANN 基础知识",
                "dirs": ["quick_start/cann_basics"],
                "community_courses": [
                    _cc("昇腾异构编程基础（速成班）",
                        "https://www.hiascend.com/developer/courses/detail/1925466587412258817",
                        "昇腾 AI 处理器硬件架构与 CANN 异构计算入门"),
                    _cc("Ascend C编程（学习路径）",
                        "https://www.hiascend.com/edu/growth/details/9614049b0d6044c28e291aea1d931a53",
                        "含异构编程基础与 Ascend C 系列课的学习路径"),
                ],
            },
        ],
        "certificate": "完成 CANN 基础入门",
        "certificate_url": "https://www.hiascend.com/edu/growth/details/9614049b0d6044c28e291aea1d931a53",
    },
    "application": {
        "goal": "应用开发（离线推理）", "level": "Python",
        "stages": [
            {
                "label": "YOLOv13 离线推理实战",
                "dirs": ["reference_practice/yolov13_offline_inference"],
                "community_courses": [
                    _cc("推理应用调优实践（学习路径）",
                        "https://www.hiascend.com/edu/growth/details/d1c1ac12e6284557a0230ba6ebb4ddc1",
                        "推理应用调优实践路径"),
                    _cc("Pytorch模型迁移（学习路径）",
                        "https://www.hiascend.com/edu/growth/details/8bb5482e933c43e98237ac7cdb14d1dc",
                        "PyTorch 模型迁移路径"),
                    _cc("【先锋计划】昇腾小模型推理迁移部署调优",
                        "https://www.hiascend.com/developer/courses/detail/2118624825056010242",
                        "小模型推理迁移部署与调优"),
                ],
            },
        ],
        "certificate": "获得应用开发证书",
        "certificate_url": COMMUNITY_FIND,
    },
    "graph": {
        "goal": "图框架开发", "level": "Python",
        "stages": [
            {
                "label": "GE / TorchAir / AutoFusion",
                "dirs": ["tutorials/ge_development", "tutorials/TorchAir_development", "tutorials/autofusion_development"],
                "community_courses": [
                    _cc("推理引擎（学习路径）",
                        "https://www.hiascend.com/edu/growth/details/c4ef987e0ae04fa3a3846c573c4766da",
                        "推理引擎 / 图模式相关路径"),
                    _cc("企业级推理部署（学习路径）",
                        "https://www.hiascend.com/edu/growth/details/89478efb20ed4592817deaf5f97f815d",
                        "企业级推理部署路径"),
                ],
            },
        ],
        "certificate": "获得图框架开发证书",
        "certificate_url": "https://www.hiascend.com/edu/growth/details/c4ef987e0ae04fa3a3846c573c4766da",
    },
    "comm": {
        "goal": "集合通信开发", "level": "Python",
        "stages": [
            {
                "label": "HCCL / HiXL",
                "dirs": ["tutorials/hccl_development", "tutorials/hixl_development"],
                "community_courses": [
                    _cc("MindCluster（学习路径）",
                        "https://www.hiascend.com/edu/growth/details/e73027aabc0a4e01a0ee3692b63474a3",
                        "集群 / 集合通信相关路径"),
                    _cc("多机多卡并行推理（学习路径）",
                        "https://www.hiascend.com/edu/growth/details/4e9c703842904f28b1289ae3e259e94a",
                        "多机多卡并行相关路径"),
                ],
            },
        ],
        "certificate": "获得集合通信开发证书",
        "certificate_url": "https://www.hiascend.com/edu/growth/details/e73027aabc0a4e01a0ee3692b63474a3",
    },
    "pyasc": {
        "goal": "算子开发（Python 版）", "level": "Python",
        "stages": [
            {
                "label": "PyASC / PyPTO / Triton",
                "dirs": ["tutorials/pyasc_operator_development", "tutorials/pypto_development"],
                "community_courses": [
                    _cc("Triton（学习路径）",
                        "https://www.hiascend.com/edu/growth/details/40da2182f5c94d4c9ddb2b582161e0f5",
                        "昇腾 Triton 算子开发路径"),
                    _cc("面向昇腾Triton算子开发（初级）",
                        "https://www.hiascend.com/developer/courses/detail/1998217338603737090",
                        "Triton 算子开发初级课"),
                    _cc("面向昇腾Triton算子开发（进阶）",
                        "https://www.hiascend.com/developer/courses/detail/2044691037452255234",
                        "Triton 算子开发进阶课"),
                    _cc("面向昇腾Triton算子开发（高级）",
                        "https://www.hiascend.com/developer/courses/detail/2114627851088642049",
                        "Triton 算子开发高级课"),
                ],
            },
        ],
        "certificate": "获得算子开发（Python 版）证书",
        "certificate_url": "https://www.hiascend.com/edu/growth/details/40da2182f5c94d4c9ddb2b582161e0f5",
    },
    "cannbot": {
        "goal": "CANNBot 算子生成", "level": "Python",
        "stages": [
            {
                "label": "CANNBot 入门与进阶",
                "dirs": ["tutorials/CANNBot"],
                "community_courses": [
                    _cc("Ascend C编程（学习路径）",
                        "https://www.hiascend.com/edu/growth/details/9614049b0d6044c28e291aea1d931a53",
                        "Ascend C 路径（CANNBot 能力建立在算子开发之上）"),
                    _cc("Ascend C Skills 全景概览",
                        "https://www.hiascend.com/developer/courses/detail/2056647289996673026",
                        "Ascend C Skills 全景"),
                ],
            },
        ],
        "certificate": "获得 CANNBot 开发证书",
        "certificate_url": "https://www.hiascend.com/edu/growth/details/9614049b0d6044c28e291aea1d931a53",
    },
    "ai_app": {
        "goal": "AI 应用开发", "level": "Python",
        "stages": [
            {
                "label": "AI 应用开发实践（RAG）",
                "dirs": ["reference_practice/ai_application_development"],
                "community_courses": [
                    _cc("RAG应用开发（学习路径）",
                        "https://www.hiascend.com/edu/growth/details/d75ff158fb3046e087440a47745b40f1",
                        "RAG 应用开发路径"),
                    _cc("RAG SDK技术原理和功能介绍",
                        "https://www.hiascend.com/developer/courses/detail/1980194995581026305",
                        "RAG SDK 原理与功能"),
                    _cc("RAG SDK部署和应用开发",
                        "https://www.hiascend.com/developer/courses/detail/1980187680169578498",
                        "RAG SDK 部署与应用开发"),
                ],
            },
        ],
        "certificate": "获得 AI 应用开发证书",
        "certificate_url": "https://www.hiascend.com/edu/growth/details/d75ff158fb3046e087440a47745b40f1",
    },
}

DEFAULT_ROLE = "开发人员"

PRACTICE_STAGE = {
    "label": "练习与在线体验",
    "courses": [
        _cc("算子刷题评测 · CANNJudge", "https://cannjudge.cn",
            "Ascend 算子编程在线刷题，实时评测"),
        _cc("算子开发者认证（入门级）",
            "https://www.hiascend.com/edu/developer-certification/detail/3a0544a46aad4d588630c15bc83f2ee9",
            "算子开发入门级认证科目（与 Ascend C 路径配套）"),
        _cc("查找学习资源", COMMUNITY_FIND,
            "社区全量检索课程、路径与认证"),
    ],
}


def community_for_dir(rel_dir, stage_community=None):
    if rel_dir in DIR_COMMUNITY:
        return DIR_COMMUNITY[rel_dir]
    for d, url in DIR_COMMUNITY.items():
        if rel_dir.startswith(d.rstrip("/") + "/") or rel_dir.startswith(d):
            return url
    return stage_community or COMMUNITY_HOME


def apply_community_links(courses, rel_dir=None, stage_community=None):
    url = community_for_dir(rel_dir, stage_community) if rel_dir else (stage_community or COMMUNITY_HOME)
    out = []
    for c in courses:
        item = dict(c)
        item["link"] = url
        item["type"] = item.get("type") or infer_resource_type(url)
        out.append(item)
    return out


def get_topic(key):
    if key not in TOPICS:
        raise KeyError(f"未知主题 '{key}'，可选：{', '.join(sorted(TOPICS))}")
    return TOPICS[key]
