#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
verify_links.py — 批量校验旅程地图里的链接是否真实可达

读取一份规格 JSON（与 build_map.py 同结构），或一组 URL，
对每条 http/https 链接做 HEAD/GET 探活，输出可达情况。
生成 HTML 前跑一遍，可拦截 404 / 拼错的路径。

用法：
  python3 verify_links.py --input spec.json
  python3 verify_links.py --urls "https://...A" "https://...B"
  python3 verify_links.py --input spec.json --strict   # 遇到不可达直接非零退出
"""
import argparse
import json
import sys
import urllib.request

TIMEOUT = 20

# GitCode 的 blob/tree 页面即使文件不存在也返回 200（SPA 兜底页），
# 因此这类链接无法用 HTTP 状态码校验，只能靠 WebFetch 目录页确认真实文件名。
GITCODE_INTERNAL = "gitcode.com/cann/cann-learning-hub"


def check(url):
    if GITCODE_INTERNAL in url and ("/blob/" in url or "/tree/" in url):
        return "SKIP", "GitCode 站内路径：SPA 始终返回 200，需以目录页真实文件名为准"
    try:
        req = urllib.request.Request(url, method="HEAD",
                                     headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
            return resp.status, ""
    except urllib.error.HTTPError as e:
        # 部分站点不支持 HEAD，降级用 GET
        if e.code in (403, 405, 501):
            try:
                req = urllib.request.Request(url, method="GET",
                                             headers={"User-Agent": "Mozilla/5.0"})
                with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
                    return resp.status, "GET 降级"
            except urllib.error.HTTPError as e2:
                return e2.code, "GET 降级"
            except Exception as e2:
                return None, str(e2)[:80]
        return e.code, ""
    except Exception as e:
        return None, str(e)[:80]


def collect_urls(spec):
    urls = []
    for st in spec.get("stages", []):
        for c in st.get("courses", []):
            u = c.get("link")
            if u and u.startswith("http"):
                urls.append((c.get("title", ""), u))
    return urls


def main():
    ap = argparse.ArgumentParser(description="校验旅程地图链接可达性")
    ap.add_argument("--input", "-i", help="规格 JSON 文件")
    ap.add_argument("--urls", nargs="*", help="直接传入 URL 列表")
    ap.add_argument("--strict", action="store_true", help="不可达时以非零码退出")
    args = ap.parse_args()

    pairs = []
    if args.input:
        with open(args.input, encoding="utf-8") as f:
            pairs = collect_urls(json.load(f))
    if args.urls:
        pairs += [("", u) for u in args.urls]

    if not pairs:
        print("没有可校验的链接。")
        return

    bad = 0
    for title, u in pairs:
        code, note = check(u)
        if code == "SKIP":
            tag = "SKIP"
        else:
            ok = isinstance(code, int) and 200 <= code < 400
            tag = "OK " if ok else "FAIL"
            if not ok:
                bad += 1
        label = f"[{title}] " if title else ""
        print(f"{tag} {code} {label}{u} {note}")
    print(f"\n共 {len(pairs)} 条，不可达 {bad} 条。")
    if args.strict and bad:
        sys.exit(1)


if __name__ == "__main__":
    main()
