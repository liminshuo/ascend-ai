# 意图 → 学习路径映射（CANN 学习中心）

> **规则层。** 地图对外卡片优先用 `scripts/topics.py` 的 `community_courses`
> （标题 = 社区真名，link = 社区详情，type = 资源类型）。  
> hub 仓库目录仅作阶段骨架 / 无 curated 时的回退抓取；**禁止**把 Notebook 名错挂到无关社区页。  
> `/developer/learn` 是枢纽页，不作单课落地。

来源：
- 社区 DLC：https://www.hiascend.com/developer/learn
- 课表参考仓：https://gitcode.com/cann/cann-learning-hub

## 意图关键词 → 主题（key + 目标）

| 用户原话（示例） | 主题 key | 目标(goal) | 主要社区入口形态 |
|------------------|----------|------------|------------------|
| 算子开发 / 自定义算子 / Ascend C | operator | 算子开发入门 | 课程 + Ascend C 学习路径 + 认证 |
| 大模型推理 / LLM 部署 / Qwen 推理 | inference | 大模型推理入门 | 文本生成推理路径 + 相关课 |
| 大模型训练 / 微调 / SFT / RL | training | 大模型训练入门 | LLM 后训练路径 + 相关课 |
| 推荐系统 / DeepFM / CTR / 召回 | recommend | 推荐系统开发 | Rec SDK 课 + 检索路径 |
| 入门 CANN / 了解 NPU / 新手 | basics | CANN 基础入门 | 异构编程速成班 + Ascend C 路径 |
| 应用开发 / 离线推理 / ACL / ATC | application | 应用开发（离线推理） | 推理应用调优路径 |
| 图框架 / GE / TorchAir / AutoFusion | graph | 图框架开发 | 推理引擎路径 |
| 集合通信 / HCCL / HiXL / 多卡 | comm | 集合通信开发 | MindCluster 等路径 |
| PyASC / PyPTO / Python 算子 | pyasc | 算子开发（Python 版） | Triton 路径 + 课 |
| CANNBot / AI 生成算子 | cannbot | CANNBot 算子生成 | Ascend C 路径 + Skills 课 |
| AI 应用 / RAG / 知识库问答 | ai_app | AI 应用开发 | RAG 应用路径 + SDK 课 |

## 各主题的阶段骨架

> 阶段划分稳定；**卡片内容以 topics.py `community_courses` 为准**。  
> 下列 `dirs` 仅说明与 hub 课表的对应关系。

### operator（算子开发）
1. **CANN 基础知识**（自动前置）← 异构编程速成班（课程）+ Ascend C编程（学习路径）
2. **算子开发入门** ← Ascend C算子开发（入门）课程
3. **Ascend C 算子开发** ← 进阶 / 高级 / Skills / MindStudio 调试·调优 / GEMM（均为课程）
4. **练习与在线体验** ← CANNJudge（练习平台）+ 算子开发者认证入门级（认证）+ 查找学习资源（检索）
- certificate：算子开发者认证（入门级）

### inference / training / recommend / application / graph / comm / pyasc / cannbot / ai_app
结构同 topics.py：公共基础 → 主题阶段（优先 community_courses）→ 练习阶段。  
证书 URL 指向对应路径或认证详情，勿挂枢纽页。

### basics（CANN 基础入门）
1. **CANN 基础知识** ← 异构编程速成班 + Ascend C编程路径
2. **练习与在线体验**
- certificate：完成 CANN 基础入门（链到 Ascend C 路径，非枢纽页）

## 资源类型（卡片 pill）

| type | 典型 URL |
| --- | --- |
| 课程 | `/developer/courses/detail/…` |
| 学习路径 | `/edu/growth/details/…` |
| 认证 | `/edu/developer-certification/detail/…` |
| 练习平台 | cannjudge.cn 等 |
| 检索 | `/developer/edu/find-resource` |
| 枢纽页 | `/developer/learn`（**仅总入口说明，不当单课卡**） |

## 公共阶段 BASICS（curated）
- 昇腾异构编程基础（速成班）→ 课程
- Ascend C编程（学习路径）→ 学习路径  
勿再用 Notebook「人工智能基础 / 什么是 NPU / 什么是 CANN / NPU 实践」标题去挂错位社区页。

## 站外 / 检索入口
- CANNJudge：https://cannjudge.cn
- 查找学习资源：https://www.hiascend.com/developer/edu/find-resource
- 课程栏目：https://www.hiascend.com/edu/courses
- 认证栏目：https://www.hiascend.com/edu/certification

## 主题覆盖度
已覆盖 11 个 key。`standard_course/` 总纲不生成旅程地图。

## 默认 persona
未说明时：角色=**开发人员**，目标=主题默认 goal，  
技术水平=C++（operator）/ Python（其余）。可按用户自述覆盖。
