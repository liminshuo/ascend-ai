# CANN 学习旅程

> 把一句学习意图（如「我想学一下推理」「我想学 Ascend C 算子开发」）整理成**可跟随的学习主线**：公共基础 → 主题阶段 → 练习与认证。  
> 本页是主线与社区真链的**查找依据**；拖入 Agent 的 [`SKILL.md`](./SKILL.md) 后，用户说「我想学 xxx」即可**自动生成本地 HTML 旅程地图**，打开后点击卡片逐步学习。**可点击入口一律指向昇腾社区学习中心（DLC）人读页**（课程 / 路径 / 认证），并标明资源类型。

| 入口 | 说明 | 链接 |
| --- | --- | --- |
| 昇腾社区学习中心（枢纽） | 路径 / 课 / 认证总门户，不作具体课入口 | [https://www.hiascend.com/developer/learn](https://www.hiascend.com/developer/learn) |
| 查找学习资源 | 全量检索 | [https://www.hiascend.com/developer/edu/find-resource](https://www.hiascend.com/developer/edu/find-resource) |
| 学习路径栏目 | DLC 路径列表 | [https://www.hiascend.com/edu/growth](https://www.hiascend.com/edu/growth) |
| 自主学习课程 | DLC 精选课 | [https://www.hiascend.com/edu/courses](https://www.hiascend.com/edu/courses) |
| 开发者认证 | DLC 认证栏目 | [https://www.hiascend.com/edu/certification](https://www.hiascend.com/edu/certification) |
| 旅程地图 Skill | 本目录 | [`SKILL.md`](./SKILL.md) |

---

## 角色导航

> 找到你的角色，直达对应主线与社区资源

| 角色 | 推荐主线 | 社区入口（DLC） |
| --- | --- | --- |
| 新手开发者 | [从这里开始：CANN 基础](#从这里开始-cann-基础-公共阶段) | [昇腾异构编程基础（速成班）](https://www.hiascend.com/developer/courses/detail/1925466587412258817) · [Ascend C编程（学习路径）](https://www.hiascend.com/edu/growth/details/9614049b0d6044c28e291aea1d931a53) |
| 大模型开发者 | [主线一：大模型训练](#主线一-大模型训练-training) · [主线二：大模型推理](#主线二-大模型推理-inference) | [LLM 后训练](https://www.hiascend.com/edu/growth/details/785809de8b7a47d496e2acbb992f7858) · [文本生成推理](https://www.hiascend.com/edu/growth/details/6bc86a3877c442308d6a92079765d899) |
| 算子开发工程师 | [主线三：算子开发](#主线三-算子开发-operator) · [延伸：Python 算子](#延伸专题-skill-可生成) | [Ascend C 编程](https://www.hiascend.com/edu/growth/details/9614049b0d6044c28e291aea1d931a53) |
| 应用开发工程师 | [主线四：应用开发](#主线四-应用开发-离线推理-application) | [推理应用调优实践](https://www.hiascend.com/edu/growth/details/d1c1ac12e6284557a0230ba6ebb4ddc1) |
| AI 应用开发者 | [延伸：AI 应用 RAG](#延伸专题-skill-可生成) | [RAG 应用开发](https://www.hiascend.com/edu/growth/details/d75ff158fb3046e087440a47745b40f1) |
| 推荐算法工程师 | [主线五：推荐系统](#主线五-推荐系统-recommend) | [查找学习资源](https://www.hiascend.com/developer/edu/find-resource) |
| 图 / 通信专项 | [延伸：图框架 / 集合通信](#延伸专题-skill-可生成) | [推理引擎](https://www.hiascend.com/edu/growth/details/c4ef987e0ae04fa3a3846c573c4766da) · [MindCluster](https://www.hiascend.com/edu/growth/details/e73027aabc0a4e01a0ee3692b63474a3) |
| 想用 AI 写算子 | [延伸：CANNBot](#延伸专题-skill-可生成) | [Ascend C 编程](https://www.hiascend.com/edu/growth/details/9614049b0d6044c28e291aea1d931a53) |

三种学习方式：

1. **社区路径 / 课程 / 认证** — 按下方主线进入昇腾 DLC 人读页  
2. **Notebook 在线体验** — 各课在社区或配套实验环境中零配置运行  
3. **本地 / 云端实操** — 按社区课程说明配置昇腾环境（CANNLab、CANNJudge 等）

---

## 前置基础（按需补）

入门阶段有 **Python + NumPy** 即可开始 CANN 基础第一课；进入算子主线再补 C/C++，进入大模型主线再补深度学习与 PyTorch。

| 基础 | 什么时候需要 |
| --- | --- |
| Python | 全部课程 |
| NumPy / PyTorch | 基础课起；训练 / 推理主线 |
| C / C++ | Ascend C 算子开发主线 |
| Linux / Git | 本地实操与社区贡献 |

社区具体课入口：[昇腾异构编程基础（速成班）](https://www.hiascend.com/developer/courses/detail/1925466587412258817) · [Ascend C编程（学习路径）](https://www.hiascend.com/edu/growth/details/9614049b0d6044c28e291aea1d931a53) · [查找学习资源](https://www.hiascend.com/developer/edu/find-resource)

---

## 从这里开始：CANN 基础（公共阶段）

> 所有学习路径的**公共基础**（阶段一，约 2h），也是后续五条主线的共同起点。  
> 具体入口用下方课程 / 路径（`/developer/learn` 是学习中心枢纽页，不作为单课落地）。

| 序号 | 社区资源（标题与落地页一致） | 说明 | 链接 |
| --- | --- | --- | --- |
| 1 | 昇腾异构编程基础（速成班） | 硬件架构 / NPU / CANN 异构入门 | [课程](https://www.hiascend.com/developer/courses/detail/1925466587412258817) |
| 2 | Ascend C编程（学习路径） | 含异构基础 → Ascend C 入门 / 进阶 / 高级 | [路径](https://www.hiascend.com/edu/growth/details/9614049b0d6044c28e291aea1d931a53) |

学完基础后，任选下面一条主线深入（可多条并行）。

---

## 学完基础，选择一条主线

完成公共基础（阶段一）后，按场景选方向深入：**先五条主线**；互不冲突，可多学。  
**可点击入口只挂昇腾社区**路径 / 课程 / 认证详情，并标明资源类型。

| 主线 | 适合人群 | 总时长 | 核心产出 | 难度 | Skill key |
| --- | --- | --- | --- | --- | --- |
| [主线一：大模型训练](#主线一-大模型训练-training) | 想做模型训练与微调 | ~16h | SFT/RL 训练与微调能力 | ★★★ | `training` |
| [主线二：大模型推理](#主线二-大模型推理-inference) | 想快速跑通大模型、做推理优化 | ~10h | 端到端推理调优能力 | ★★☆ | `inference` |
| [主线三：算子开发](#主线三-算子开发-operator) | 想掌握底层编程、做算子级优化 | ~20h | 自定义算子开发与接入 | ★★★ | `operator` |
| [主线四：应用开发（离线推理）](#主线四-应用开发-离线推理-application) | 想做 ACL 离线推理与应用部署 | ~6h | ATC 编译 + ACL 推理 + 调优 | ★★☆ | `application` |
| [主线五：推荐系统](#主线五-推荐系统-recommend) | 想做推荐/召回业务落地 | ~8h | CTR 排序 + 召回全链路 | ★★☆ | `recommend` |

> 旅程地图由 Skill 按主题 key 生成。PyASC、图框架、集合通信、CANNBot、AI 应用等见 [延伸专题](#延伸专题-skill-可生成)。

---

### 主线一：大模型训练（`training`）

> 从微调实战到 SFT/RL 训练全流程，系统掌握大模型训练与性能优化能力。

**阶段一：CANN 基础（公共，约 2h）** — 已在上文完成 → 直接进入后续阶段

**阶段二：微调实战案例（SwanLab 共建）**

| 序号 | 课程 | 课程内容 | 状态 | 社区入口 |
| --- | --- | --- | --- | --- |
| 1 | 医学模型微调 | Qwen3 医学领域 SFT + SwanLab 可视化 | 已上线 | [LLM 微调](https://www.hiascend.com/edu/growth/details/85a0535925534e73a8416e3d0cda65e2) · [LLM 后训练](https://www.hiascend.com/edu/growth/details/785809de8b7a47d496e2acbb992f7858) |
| 2 | ms-swift 框架微调 | ms-swift 框架微调 + SwanLab 可视化 | 建设中 | [LLM 微调](https://www.hiascend.com/edu/growth/details/85a0535925534e73a8416e3d0cda65e2) |
| 3 | Qwen3-smolVLM 多模态微调 | 多模态拼接微调 + SwanLab 可视化 | 建设中 | [多模态微调](https://www.hiascend.com/edu/growth/details/9886471faf0045329c7c8ec51d818c4b) · [多模态大模型训练微调](https://www.hiascend.com/developer/courses/detail/1980469166009548801) |
| 4 | CosyVoice 语音微调 | 语音模型微调 + SwanLab 可视化 | 建设中 | [多模态微调](https://www.hiascend.com/edu/growth/details/9886471faf0045329c7c8ec51d818c4b) |

> 案例正迁入 `contrib/tutorials/swanlab_examples/`，完成后可在 CANNLab 体验。另有 MNIST、数学解题 LoRA 等已上线样例。

**阶段三：SFT/RL 初阶**

| 序号 | 课程 | 课程内容 | 状态 | 社区入口 |
| --- | --- | --- | --- | --- |
| 5 | SFT 训练系列（初阶） | Wordle 与 SFT 原理 / TorchTitan-FSDP 环境 / Qwen3-1.7B 基线训练与评测 / 融合算子与 Profiling | 已上线 | [MindSpeed 大模型训练全流程（速成班）](https://www.hiascend.com/developer/courses/detail/1998643482066972673) · [MindSpeed LLM 训练框架和特性介绍](https://www.hiascend.com/developer/courses/detail/1910963014913622017) |
| 6 | RL 训练系列（初阶） | verl+vLLM-Ascend / RL+GRPO 与 KL 稳定性 / Wordle Agent Loop 与奖励 / 指标监控与崩塌调优 | 已上线 | [MindSpeed RL 强化学习全流程](https://www.hiascend.com/developer/courses/detail/2013153653191442434) · [verl 强化学习全流程](https://www.hiascend.com/developer/courses/detail/2071849100282081282) |

**阶段四：SFT/RL 中阶**

| 序号 | 课程 | 课程内容 | 状态 | 社区入口 |
| --- | --- | --- | --- | --- |
| 7 | SFT 训练系列（中阶） | Attention（SDPA→VarLen）/ Sequence Packing 与 TND / FSDP·TP·CP / VarLen+CP 与 TP2/FSDP2 | 已上线 | [大语言模型训练](https://www.hiascend.com/edu/growth/details/f81218a9cc1641fa8ca1467651da1418) · [MindSpeed LLM 基于 Qwen2.5-7B 开发实践](https://www.hiascend.com/developer/courses/detail/1935570808551755777) |
| 8 | RL 训练系列（中阶） | FSDP→TorchTitan-NPU FSDP2 / offload·TND / Wordle 三步训练 / 后端切换排查 | 已上线 | [MindSpeed 预训练、微调与强化学习](https://www.hiascend.com/developer/courses/detail/1998576696487342081) |

**阶段五：SFT/RL 高阶**

| 序号 | 课程 | 课程内容 | 状态 | 社区入口 |
| --- | --- | --- | --- | --- |
| 9 | SFT 训练系列（高阶） | 计算图静态化与 AutoFuse、selective AC 显存调优 | 建设中 | [昇腾大模型训练开发（PyTorch）](https://www.hiascend.com/edu/growth/details/a4e2517feebc47eda47e35d516b5d3a1) |
| 10 | RL 训练系列（高阶） | 性能基线与瓶颈定位，FSDP2/TP/CP/PP 并行调优 | 建设中 | [训练开发者认证（工作级）](https://www.hiascend.com/edu/developer-certification/detail/5fc08c73e1924b5f8ba1a878fa3ed25b) |

| 类型 | 社区资源 |
| --- | --- |
| 学习路径 | [LLM 后训练](https://www.hiascend.com/edu/growth/details/785809de8b7a47d496e2acbb992f7858) · [大语言模型训练](https://www.hiascend.com/edu/growth/details/f81218a9cc1641fa8ca1467651da1418) · [大模型训练初体验](https://www.hiascend.com/edu/growth/details/9e4f9adb505f4830b3dc370af4926a39) · [LLM 微调](https://www.hiascend.com/edu/growth/details/85a0535925534e73a8416e3d0cda65e2) |
| 课程 | [MindSpeed 大模型训练全流程（速成班）](https://www.hiascend.com/developer/courses/detail/1998643482066972673) · [MindSpeed RL 强化学习全流程](https://www.hiascend.com/developer/courses/detail/2013153653191442434) · [verl 强化学习全流程](https://www.hiascend.com/developer/courses/detail/2071849100282081282) · [MindSpeed LLM 训练框架和特性介绍](https://www.hiascend.com/developer/courses/detail/1910963014913622017) |
| 认证 | [训练开发者认证（入门级）](https://www.hiascend.com/edu/developer-certification/detail/d49a9915599e49be8e978db5dce42d88) · [训练开发者认证（工作级）](https://www.hiascend.com/edu/developer-certification/detail/5fc08c73e1924b5f8ba1a878fa3ed25b) |

---

### 主线二：大模型推理（`inference`）

> 以 Qwen3 端到端推理为主线，理论课件 + 实践双轨：跑通推理 → 发现瓶颈 → 融合优化 → 量化与算子 → 图模式调优。

**阶段一：CANN 基础（公共，约 2h）** — 已在上文完成

**阶段二：初阶 — 跑通推理（约 3–4h）**

| 序号 | 课程 | 课程内容 | 状态 | 社区入口 |
| --- | --- | --- | --- | --- |
| 1 | 章节介绍 | 全流程概览 | 已上线 | [文本生成推理](https://www.hiascend.com/edu/growth/details/6bc86a3877c442308d6a92079765d899) |
| 2 | Baseline 推理 | 跑通 Qwen3-8B BF16 推理 | 已上线 | [文本生成推理](https://www.hiascend.com/edu/growth/details/6bc86a3877c442308d6a92079765d899) · [vLLM-Ascend 推理部署及模型迁移适配](https://www.hiascend.com/developer/courses/detail/2071428481241497602) |
| 3 | Profiling 分析 | 定位 RMSNorm 等小算子链路瓶颈 | 已上线 | [基于 vllm-ascend 的 profiling 采集及性能分析](https://www.hiascend.com/developer/courses/detail/2060174102022684674) · [推理性能调优](https://www.hiascend.com/edu/growth/details/e73ec56894914c64bd0285101955e58b) |

**阶段三：中阶 — 融合优化与量化（约 4–6h）**

| 序号 | 课程 | 课程内容 | 状态 | 社区入口 |
| --- | --- | --- | --- | --- |
| 4 | Dense RMSNorm NPU 融合优化 | 融合开关 A/B 对比 | 已上线 | [推理性能调优](https://www.hiascend.com/edu/growth/details/e73ec56894914c64bd0285101955e58b) |
| 5 | 量化 Qwen3-8B | AMCT 导出 W8A8 → 量化推理 → Profiling | 已上线 | [模型量化压缩](https://www.hiascend.com/edu/growth/details/4a0ce7932c534d42816b6fa3b8ff4dbc) · [msModelSlim 量化精度调优](https://www.hiascend.com/developer/courses/detail/2049008829341143041) |
| 6 | 自定义量化算子接入 | Ascend C 实现并替换瓶颈算子（建议先修算子主线） | 已上线 | [Ascend C 编程](https://www.hiascend.com/edu/growth/details/9614049b0d6044c28e291aea1d931a53) · [Ascend C 算子开发（入门）](https://www.hiascend.com/developer/courses/detail/1691696509765107713) |

**阶段四：高阶 — 图模式调优（可选）**

| 序号 | 课程 | 课程内容 | 状态 | 社区入口 |
| --- | --- | --- | --- | --- |
| 7 | 图模式优化 | eager / ge_graph / npugraph_ex 对比 | 已上线 | [推理引擎](https://www.hiascend.com/edu/growth/details/c4ef987e0ae04fa3a3846c573c4766da) |
| 8 | GE Graph o_proj 权重预取 | 关闭 / 16MiB / 32MiB 三组对比 | 已上线 | [推理引擎](https://www.hiascend.com/edu/growth/details/c4ef987e0ae04fa3a3846c573c4766da) · [企业级推理部署](https://www.hiascend.com/edu/growth/details/89478efb20ed4592817deaf5f97f815d) |

| 类型 | 社区资源 |
| --- | --- |
| 学习路径 | [文本生成推理](https://www.hiascend.com/edu/growth/details/6bc86a3877c442308d6a92079765d899) · [多机多卡并行推理](https://www.hiascend.com/edu/growth/details/4e9c703842904f28b1289ae3e259e94a) · [模型量化压缩](https://www.hiascend.com/edu/growth/details/4a0ce7932c534d42816b6fa3b8ff4dbc) · [推理性能调优](https://www.hiascend.com/edu/growth/details/e73ec56894914c64bd0285101955e58b) · [推理引擎](https://www.hiascend.com/edu/growth/details/c4ef987e0ae04fa3a3846c573c4766da) |
| 课程 | [LLM 多机多卡并行推理](https://www.hiascend.com/developer/courses/detail/2004093014389059585) · [vLLM-Ascend 推理部署及模型迁移适配](https://www.hiascend.com/developer/courses/detail/2071428481241497602) · [基于 vllm-ascend 的 profiling 采集及性能分析](https://www.hiascend.com/developer/courses/detail/2060174102022684674) · [MindSpore Transformers LLM 推理迁移与实践](https://www.hiascend.com/developer/courses/detail/1995425210102222850) |
| 认证 | [推理开发者认证（入门级）](https://www.hiascend.com/edu/developer-certification/detail/a2a114ff736e4e3eaae4e09b2caea8e9) · [推理开发者认证（工作级）](https://www.hiascend.com/edu/developer-certification/detail/583e838e9cfd4417b0c0f5e88eed6740) |

---

### 主线三：算子开发（`operator`）

> 从「10 分钟体验算子」到 Ascend C 编程范式，具备自定义算子开发与工程化能力。

**阶段一：CANN 基础（公共，约 2h）** — 已在上文完成

**阶段二：体验算子（约 2h）**

| 序号 | 课程 | 课程内容 | 状态 | 社区入口 |
| --- | --- | --- | --- | --- |
| 1 | 10 分钟体验自定义算子 | Ascend C 编写与编译全流程感知 | 已上线 | [Ascend C 算子开发（入门）](https://www.hiascend.com/developer/courses/detail/1691696509765107713) · [昇腾异构编程基础（速成班）](https://www.hiascend.com/developer/courses/detail/1925466587412258817) |
| 2 | 10 分钟体验算子 API 调用 | 算子调用与价值感知 | 已上线 | [算子模板库](https://www.hiascend.com/developer/courses/detail/1925707689125974018) |

**阶段三：系统学习（约 12h）**

| 序号 | 课程 | 课程内容 | 状态 | 社区入口 |
| --- | --- | --- | --- | --- |
| 3 | Ascend C 算子开发系列（Kernel 直调版） | 概念、编程范式、Vector / Cube / 融合与调试调优 | 已上线 | [Ascend C 编程](https://www.hiascend.com/edu/growth/details/9614049b0d6044c28e291aea1d931a53) · [Ascend C 算子开发（入门）](https://www.hiascend.com/developer/courses/detail/1691696509765107713) · [Ascend C 算子开发（进阶）](https://www.hiascend.com/developer/courses/detail/1696414606799486977) |

**阶段四：算子开发实战**

| 序号 | 课程 | 课程内容 | 状态 | 社区入口 |
| --- | --- | --- | --- | --- |
| 4 | Ascend C 算子开发系列（工程版） | 工程化流程、开源贡献规范 | 已上线 | [Ascend C 算子开发（高级）](https://www.hiascend.com/developer/courses/detail/1696690858236694530) · [Ascend C Skills 全景概览](https://www.hiascend.com/developer/courses/detail/2056647289996673026) |
| 5 | Vector 算子开发 | Vector 算子开发实战 | 建设中 | [Ascend C 算子开发（进阶）](https://www.hiascend.com/developer/courses/detail/1696414606799486977) |
| 6 | Conv 算子开发实战 | 卷积算子核心概念与实践 | 建设中 | [CATLASS 算子开发（入门）](https://www.hiascend.com/developer/courses/detail/1995421335433535490) |
| 7 | MC2 融合算子实战 | Matmul / Conv / 通算融合 | 已上线 | [GEMM 类算子调优](https://www.hiascend.com/developer/courses/detail/1925473416036966402) · [GEMM 类算子调优路径](https://www.hiascend.com/edu/growth/details/66ce04408bdc4e2b9db8169b66aff9a6) |

**阶段五：算子性能优化（进阶）**

| 类别 | 课程 | 课程内容 | 社区入口 |
| --- | --- | --- | --- |
| Vector | Vector 算子优化 | RegBase 改写、融合、多核与访存 | [MindStudio 算子调优工具](https://www.hiascend.com/developer/courses/detail/2046475214141014018) |
| Cube | 矩阵乘算子优化 | Tiling、搬运、尾轮负载、低精度量化 | [GEMM 类算子调优](https://www.hiascend.com/developer/courses/detail/1925473416036966402) |
| CV 融合 | Cube/Vector 融合 | FA / 注意力残差 / KDA 等 | [Ascend C 算子开发（高级）](https://www.hiascend.com/developer/courses/detail/1696690858236694530) |
| 通算融合 | 通信与计算融合 | MoE Token 分发与合并 | [MindCluster](https://www.hiascend.com/edu/growth/details/e73027aabc0a4e01a0ee3692b63474a3) |
| 专题 | SIMD VF / SIMT / Scalar | 广播归约、不规则访存、标量开销 | [MindStudio 算子调试工具](https://www.hiascend.com/developer/courses/detail/2046763915643473921) |

| 类型 | 社区资源 |
| --- | --- |
| 学习路径 | [Ascend C 编程](https://www.hiascend.com/edu/growth/details/9614049b0d6044c28e291aea1d931a53) · [GEMM 类算子调优](https://www.hiascend.com/edu/growth/details/66ce04408bdc4e2b9db8169b66aff9a6) · [Triton](https://www.hiascend.com/edu/growth/details/40da2182f5c94d4c9ddb2b582161e0f5) |
| 课程 | [Ascend C 算子开发（入门）](https://www.hiascend.com/developer/courses/detail/1691696509765107713) · [Ascend C 算子开发（进阶）](https://www.hiascend.com/developer/courses/detail/1696414606799486977) · [Ascend C 算子开发（高级）](https://www.hiascend.com/developer/courses/detail/1696690858236694530) · [GEMM 类算子调优](https://www.hiascend.com/developer/courses/detail/1925473416036966402) · [CATLASS 算子开发（入门）](https://www.hiascend.com/developer/courses/detail/1995421335433535490) |
| 认证 | [算子开发者认证（入门级）](https://www.hiascend.com/edu/developer-certification/detail/3a0544a46aad4d588630c15bc83f2ee9) · [算子开发者认证（工作级）](https://www.hiascend.com/edu/developer-certification/detail/92d0e017a21c4939af509ba985e635a5) |

---

### 主线四：应用开发·离线推理（`application`）

> 以 YOLOv13 目标检测为例：ONNX 导出 → ATC 离线编译 → ACL 推理 → 性能调优。

**阶段一：CANN 基础（公共，约 2h）** — 已在上文完成

**阶段二：YOLOv13 离线推理实战（约 4h）**

| 序号 | 课程 | 课程内容 | 状态 | 社区入口 |
| --- | --- | --- | --- | --- |
| 1 | 章节介绍 | 学习目标、流程和目录 | 已上线 | [推理应用调优实践](https://www.hiascend.com/edu/growth/details/d1c1ac12e6284557a0230ba6ebb4ddc1) |
| 2 | 环境准备与模型转换 | 导出 ONNX，ATC 生成 OM | 已上线 | [Pytorch 模型迁移](https://www.hiascend.com/edu/growth/details/8bb5482e933c43e98237ac7cdb14d1dc) |
| 3 | ACL 离线推理 | 编译并运行 ACL C++ 推理 | 已上线 | [昇腾小模型推理迁移部署调优](https://www.hiascend.com/developer/courses/detail/2118624825056010242) |
| 4 | 结果处理与性能调优 | 后处理、可视化、多流参数 | 已上线 | [推理性能调优](https://www.hiascend.com/edu/growth/details/e73ec56894914c64bd0285101955e58b) · [MindStudio 系统调优工具](https://www.hiascend.com/developer/courses/detail/2047203003227951106) |
| 5 | 章节练习 | 巩固转换、推理与调优 | 已上线 | [查找学习资源](https://www.hiascend.com/developer/edu/find-resource) |

| 类型 | 社区资源 |
| --- | --- |
| 学习路径 | [推理应用调优实践](https://www.hiascend.com/edu/growth/details/d1c1ac12e6284557a0230ba6ebb4ddc1) · [Pytorch 模型迁移](https://www.hiascend.com/edu/growth/details/8bb5482e933c43e98237ac7cdb14d1dc) · [推理性能调优](https://www.hiascend.com/edu/growth/details/e73ec56894914c64bd0285101955e58b) |
| 课程 | [昇腾小模型推理迁移部署调优](https://www.hiascend.com/developer/courses/detail/2118624825056010242) · [MindStudio 系统调优工具](https://www.hiascend.com/developer/courses/detail/2047203003227951106) |
| 检索 | [查找学习资源](https://www.hiascend.com/developer/edu/find-resource) |

---

### 主线五：推荐系统（`recommend`）

> 基于 Torch-RecHub：排序 → 召回 → 多任务 → 工程化 → NPU 推理优化。

**阶段一：CANN 基础（公共，约 2h）** — 已在上文完成

**阶段二：跑通 CTR（约 2h）**

| 序号 | 课程 | 课程内容 | 状态 | 社区入口 |
| --- | --- | --- | --- | --- |
| 1 | QuickStart：CTR 预测（DeepFM） | DataFrame → Feature → DeepFM → CTRTrainer → AUC | 已上线 | [认识安装 Rec SDK](https://www.hiascend.com/developer/courses/detail/1906524655197753346) · [如何利用 Rec SDK 完成推荐模型训练](https://www.hiascend.com/developer/courses/detail/1906525736459960321) |

**阶段三：进阶建模（约 4h）**

| 序号 | 课程 | 课程内容 | 状态 | 社区入口 |
| --- | --- | --- | --- | --- |
| 2 | 序列兴趣建模：DIN | 历史行为序列与 DIN attention | 已上线 | [Mindx-RecSDK 架构及特性解读](https://www.hiascend.com/developer/courses/detail/2009234890159132674) |
| 3 | 匹配/召回：DSSM + Annoy | 双塔召回与向量 Top-K | 已上线 | [检索应用开发](https://www.hiascend.com/edu/growth/details/310d161ab02c45958f9bc3d8fbbec51e) · [Index SDK 检索应用开发](https://www.hiascend.com/developer/courses/detail/1990696096522833921) |
| 4 | 多任务学习：MMOE | expert / gate / tower | 已上线 | [如何利用 Rec SDK 完成推荐模型训练](https://www.hiascend.com/developer/courses/detail/1906525736459960321) |

**阶段四：工程化（约 2h）**

| 序号 | 课程 | 课程内容 | 状态 | 社区入口 |
| --- | --- | --- | --- | --- |
| 5 | 实验跟踪 | WandB / SwanLab / TensorBoardX | 已上线 | [自主学习课程](https://www.hiascend.com/edu/courses) |
| 6 | 模型导出与推理验证 | ONNX 导出、ONNXRuntime、量化入口 | 已上线 | [Pytorch 模型迁移](https://www.hiascend.com/edu/growth/details/8bb5482e933c43e98237ac7cdb14d1dc) |

**阶段五：NPU 推理优化（约 1h）**

| 序号 | 课程 | 课程内容 | 状态 | 社区入口 |
| --- | --- | --- | --- | --- |
| 7 | DIN 多进程控核推理 | TorchAir 整图控核与 latency 统计 | 已上线 | [推理引擎](https://www.hiascend.com/edu/growth/details/c4ef987e0ae04fa3a3846c573c4766da) · [推理性能调优](https://www.hiascend.com/edu/growth/details/e73ec56894914c64bd0285101955e58b) |

| 类型 | 社区资源 |
| --- | --- |
| 课程 | [认识安装 Rec SDK](https://www.hiascend.com/developer/courses/detail/1906524655197753346) · [如何利用 Rec SDK 完成推荐模型训练](https://www.hiascend.com/developer/courses/detail/1906525736459960321) · [Mindx-RecSDK 架构及特性解读](https://www.hiascend.com/developer/courses/detail/2009234890159132674) · [Index SDK 检索应用开发](https://www.hiascend.com/developer/courses/detail/1990696096522833921) |
| 学习路径 | [检索应用开发](https://www.hiascend.com/edu/growth/details/310d161ab02c45958f9bc3d8fbbec51e) |
| 检索 | [查找学习资源](https://www.hiascend.com/developer/edu/find-resource) |
| 课程栏目 | [自主学习课程](https://www.hiascend.com/edu/courses) |

---

### 延伸专题（Skill 可生成）

五条主线之外，还有下列延伸方向；意图命中时用对应 Skill key 出图。

| 专题 | Skill key | 阶段要点 | 社区资源 |
| --- | --- | --- | --- |
| CANN 基础入门（仅公共） | `basics` | 异构编程基础 → Ascend C 路径 | [昇腾异构编程基础（速成班）](https://www.hiascend.com/developer/courses/detail/1925466587412258817) · [Ascend C编程（学习路径）](https://www.hiascend.com/edu/growth/details/9614049b0d6044c28e291aea1d931a53) |
| 算子开发 · Python（PyASC / PyPTO） | `pyasc` | PyASC → PyPTO | [Triton 路径](https://www.hiascend.com/edu/growth/details/40da2182f5c94d4c9ddb2b582161e0f5) · [Triton 算子开发（初级）](https://www.hiascend.com/developer/courses/detail/1998217338603737090) · [Triton 算子开发（进阶）](https://www.hiascend.com/developer/courses/detail/2044691037452255234) · [Triton 算子开发（高级）](https://www.hiascend.com/developer/courses/detail/2114627851088642049) |
| 图框架（GE / TorchAir / AutoFusion） | `graph` | GE → TorchAir → AutoFusion | [推理引擎](https://www.hiascend.com/edu/growth/details/c4ef987e0ae04fa3a3846c573c4766da) · [企业级推理部署](https://www.hiascend.com/edu/growth/details/89478efb20ed4592817deaf5f97f815d) |
| 集合通信（HCCL / HiXL） | `comm` | HCCL → HiXL | [MindCluster](https://www.hiascend.com/edu/growth/details/e73027aabc0a4e01a0ee3692b63474a3) · [多机多卡并行推理](https://www.hiascend.com/edu/growth/details/4e9c703842904f28b1289ae3e259e94a) |
| CANNBot 算子生成 | `cannbot` | CANNBot 入门与进阶 | [Ascend C 编程](https://www.hiascend.com/edu/growth/details/9614049b0d6044c28e291aea1d931a53) · [Ascend C Skills 全景概览](https://www.hiascend.com/developer/courses/detail/2056647289996673026) |
| AI 应用（RAG） | `ai_app` | RAG 知识库问答端到端 | [RAG 应用开发](https://www.hiascend.com/edu/growth/details/d75ff158fb3046e087440a47745b40f1) · [RAG SDK 技术原理和功能介绍](https://www.hiascend.com/developer/courses/detail/1980194995581026305) · [RAG SDK 部署和应用开发](https://www.hiascend.com/developer/courses/detail/1980187680169578498) · [Index SDK 检索应用开发](https://www.hiascend.com/developer/courses/detail/1990696096522833921) |

---

## 社区入口一览

| 栏目 | 用途 | 链接 |
| --- | --- | --- |
| 昇腾社区学习中心（枢纽） | 总门户；具体学习请下钻路径 / 课 / 认证 | [https://www.hiascend.com/developer/learn](https://www.hiascend.com/developer/learn) |
| 查找学习资源 | 全量检索 | [https://www.hiascend.com/developer/edu/find-resource](https://www.hiascend.com/developer/edu/find-resource) |
| 学习路径栏目 | DLC 路径列表 | [https://www.hiascend.com/edu/growth](https://www.hiascend.com/edu/growth) |
| 自主学习课程 | DLC 精选课 | [https://www.hiascend.com/edu/courses](https://www.hiascend.com/edu/courses) |
| 开发者认证 | DLC 认证栏目 | [https://www.hiascend.com/edu/certification](https://www.hiascend.com/edu/certification) |

---

## 用 Skill 生成「学习旅程地图」HTML

当你（或智能助手）听到「我想学 XXX」时，按主题 key 一键出图：

```bash
# 在本目录下
python3 scripts/generate.py --topic inference --out ./out/推理学习旅程.html \
  --role 开发人员 --goal 大模型推理入门 --level 入门
```

| 参数 | 说明 |
| --- | --- |
| `--topic` | 上表 11 个 key 之一 |
| `--role` / `--goal` / `--level` | 可选画像；缺省见 [`scripts/topics.py`](./scripts/topics.py) |
| `--out` | 输出 HTML 路径 |

资讯 / 案例意图（「有什么新技术」「实践案例」）走博客墙：

```bash
python3 scripts/build_blog_wall.py --out ./out/技术博客墙.html
```

规则真源：

- 人类可读：[`references/intent-map.md`](./references/intent-map.md)  
- 脚本消费：[`scripts/topics.py`](./scripts/topics.py)  
- Skill 说明：[`SKILL.md`](./SKILL.md)

---

## 维护说明

1. 社区路径 / 课 / 认证 URL 变更时，更新本页对应真链（标题与落地页同名同义）。  
2. 增删主题或调整阶段：同步改 `scripts/topics.py` 与 `references/intent-map.md`，再更新本页。  
3. 具体课入口用路径 / 课程 / 认证详情页；**不要把枢纽页 `/developer/learn` 当成单课落地**。  
