---
name: llms-txt-generate
description: >-
  斜杠唤起。仅当用户输入 /llms-txt-generate 时使用。后面可接站点根 URL。
  诊断并给出精选 llms.txt：有抓取表以表为主，无表用 Sitemap 弱输入。输出 Part1/Part2 HTML，可下载 llms.txt。
disable-model-invocation: true
---

# llms.txt 配置诊断（抓取表 / Sitemap）

单独斜杠 `/llms-txt-generate` 仍可用。站点根走 `/geo-checklist-audit` 时会读本说明接力出稿，不要再让用户敲本斜杠。

## 核心命题

`llms.txt` 是给大模型 / Agent 的**精选知识索引入口**，不是 sitemap 全量拷贝。本 Skill 回答：在给定输入约束下应推荐哪些核验过的 URL、如何分组、**是否需要分册**（及用户要求时的分册方案），以及数据缺口在哪里。

## Sitemap 使用规则（必守）

| 场景 | Sitemap 角色 | Agent 做什么 |
|------|--------------|--------------|
| **有抓取表** | **轻量核对** | 主路径仍是 CSV。发现 Sitemap 后只做可达性、大致条数/层级、多 host·文档子站信号、与表的**覆盖缺口**对照；结论写入 Part1「Sitemap 核对」与问题列表。**禁止**把 Sitemap 全量 URL 写入优化稿。 |
| **无抓取表** | **弱输入** | 以 Sitemap（及 robots 中的 `Sitemap:`）为候选池，抽样入口与路径簇做门户级精选；报告必须标明「弱输入、缺 Title/H1/Description、质量受限」。说明尽量来自可核验的页面 Title（抽样 GET）或路径语义+「待确认」；**禁止**把 Sitemap 当全站枚举灌进 llms.txt。 |

发现 Sitemap 的顺序：用户给出的 URL → `robots.txt` 中的 `Sitemap:` / `sitemap:` → 常见路径如 `/sitemap.xml`（仅作候选，失败记入数据缺口）。

**不要做（Sitemap）**

- 深挖嵌套 index 的全量 URL 清单质量（lastmod、过期等）——那不是本 Skill 职责
- 无标题元数据时凭路径臆造长说明
- 与 `robots-txt-audit` 抢活：本 Skill **不**评价「robots 是否声明了 Sitemap」的合规性，只**消费**已声明/可发现的 Sitemap

## 范围（必守）

**要做**

| 项 | 要求 |
|----|------|
| 输入 | 站点根 URL + **抓取表（优先）** 和/或 **Sitemap（有表=核对，无表=弱输入）** |
| 结构分析 | 从可用字段归纳主要内容分类；标出各分类代表性核心页 |
| 筛选 | 保留有明确主题与信息价值的页；排除失效、无价值重复、纯导航、不宜推荐资源 |
| 生成 | 按 [llmstxt.org](https://llmstxt.org) 形态输出精选 `llms.txt` |
| 报告 | HTML：Part1 分析说明（含 Sitemap 小节）+ Part2 优化后的 llms.txt；提供下载；可导出 PDF |
| 诚实边界 | 不编造 URL；信息不足标「待核验 / 待确认」；不凭路径臆测正文 |

**不要做**

- 声称已理解全部页面正文（CSV 只有元数据、Sitemap 弱输入时尤甚）
- 把 SEO 排名 / 流量指标直接当作「对 AI 的价值」
- 无差别地把抓取表或 Sitemap 全部 URL 写入 llms.txt
- 在无最终有效 URL 时把 3xx 源地址当推荐入口

## 输入（Agent 开跑前收齐）

| 字段 | 必填 | 说明 |
|------|------|------|
| 站点根 URL | 是 | 如 `https://www.huaweicloud.com/` |
| 抓取表路径 | 可选 | 有则主输入。不交则 Sitemap 弱输入，报告标明质量受限。不要追问收录范围 / 站点名 / 主推版本 |

Sitemap 由 Agent 从 `robots.txt` 的 `Sitemap:` 或 `/sitemap.xml` 发现，不要向人另要。二者皆无：报告标待确认。

### CSV 列期望（有则用，无则记入「数据缺失」）

优先识别（列名大小写/中英别名可归一）：

`Address` / `URL` · `Status Code` · `Title` · `H1` · `Meta Description` · `Indexability` · `Canonical` · `Redirect URL` · `Inlinks` · `Content Type`

缺列时：**不要编造字段值**；在报告「数据缺失」中列出，并收紧推荐条数。

## 工作流

```
Step 0  输入
        · 站点根 URL +（CSV 和/或 Sitemap）+ 可选范围/站点名
        · 判定模式：有表 →「表主 + Sitemap 轻量核对」；无表 →「Sitemap 弱输入」
        · 读本 Skill 与 [report-template.html](report-template.html)

Step 1a 有表：载入与清洗抓取表
        · 只保留同站（或白名单域名）HTML 类 URL
        · 状态码：优先 200；3xx 记入核验，推荐用最终有效 URL（表内 Redirect URL 或同日 HEAD/GET）
        · 4xx/5xx、非 HTML、明显资产 URL → 排除并记「失效 / 不适配」
        · 去重：相同规范 URL / 明显参数变体；保留信息更完整的一条

Step 1b Sitemap（两种模式共用入口，用法不同）
        · 发现：用户给定 → robots.txt 的 Sitemap: → 常见 /sitemap.xml
        · 有表·轻量核对：可达？index 还是 urlset？粗估 loc 规模；是否多 host / 文档子域；
          与 CSV 路径前缀对照，列出「表未覆盖但 Sitemap 有」的缺口类型（不枚举全量 URL）
        · 无表·弱输入：解析 urlset / 有限层 index（控制深度与条数上限，避免全站灌入）；
          按路径簇抽样候选；对拟写入条目尽量补一次 Title（HEAD/GET），否则短说明+待确认
        · 无论哪模式：禁止 Sitemap 全量写入 llms.txt

Step 2  分析网站结构（Part1 素材）
        · 有表：结合 URL 路径 + Title + H1 + Meta Description + 内链度归纳分类
        · 无表：结合 Sitemap 路径簇 + 抽样 Title + 用户范围说明归纳分类（置信度更低）
          例：云产品、技术文档、解决方案、开发者资源、帮助中心
        · 每类标出代表性核心页（入口、总览、快速开始、主推产品）
        · 禁止仅凭路径猜测用途；字段不足 →「待核验」

Step 3  筛选页面
        · 保留：主题清晰、对 Agent 有导航/知识价值的页
        · 排除：失效、无价值重复、纯导航壳、登录/购物车/活动噪声（除非范围要求）
        · 不把 SEO 指标当价值主依据
        · 精选上限建议：根文件门户级每分类 ≤15 条；全文件建议控制在可读规模（如 ≤80～120 条）
        · 弱输入模式下条数再收紧，优先入口/总览级

Step 4  Agent 自主判断是否需要分册（必做）
        · 按下方「分册判断标准」给出结论：需要 / 不需要
        · 写清依据（条数、多 host、帮助中心/文档站、多语言、用户明确要求等；
          Sitemap 核对发现的多 host / 大体量可作为依据）
        · 若结论为「需要」，或用户明确要求分册：必须输出「分册方案」
          （根文件只做门户 + ## 分册链；各分册文件名、范围、拟收录来源、预估体量）
        · 若结论为「不需要」且用户未要求：报告写结论与依据即可；
          可附一句「若业务仍要拆，可按下列备选方案」的轻量备选（可选）
        · 用户说「要分册」时：即使体积未超阈值，也按场景给出可执行分册方案（不得拒绝）

Step 5  生成 llms.txt（优化稿）
        · # 站点或项目名
        · > 一句 Blockquote：内容范围 +「精选索引、非全站枚举」
          （弱输入时加一句：基于 Sitemap 抽样，建议后续补抓取表）
        · ## 分类
        · - [标题](绝对URL): 短说明（来自 Title/H1/Description 的可核验信息；勿臆测）
        · 有表：仅使用表内存在且经过核验的 URL（Sitemap 缺口只进报告，不进稿，除非用户点名补入且已核验）
        · 无表：仅使用 Sitemap 候选中已核验可达、且已尽量补标题的精选 URL
        · 无法确认内容的条目：不写进正文，或单独列入报告「待人工核验」，禁止瞎写说明
        · 若已决定分册：根文件保持精选门户，用 ## 分册 链接各 llms-*.txt；
          同步产出各分册 txt（或在方案中标明待补数据后再写）

Step 6  链接核验（抽样 + 关键入口）
        · 对拟写入条目做可达性核验（至少：首页、各分类代表页、全部写入条目若总量可控）
        · 记录：通过 / 重定向后采用 / 失败；失败不得进入优化稿
        · 核验结论写入「问题判定」，报告不单独展示核验表

Step 7  输出
        · 优化后的 llms.txt 纯文本文件（可供下载）；分册时另产出各分册文件
        · 复制 report-template.html → 填占位符 → HTML 诊断报告（含分册判断与 Sitemap 小节）
        · GEO 仓库：docs/ 与 report-serve/ 双写报告与 txt
        · 遵守下方「壳层与布局」

Step 8  导出 PDF（可选）
        · 顶栏「导出 PDF」→ 打印 → 存储为 PDF
        · 勿删 #btn-export-pdf 与 @media print
```

## 分册判断标准（Agent 必用）

**倾向「需要分册」**（满足任一即认真评估，通常判需要）：

| 信号 | 说明 |
|------|------|
| 体量 | 拟写入根文件条目 ≳ **80～120**，或单分类持续 >15 且仍要加厚 |
| 多入口域 | 抓取表 / Sitemap 核对 / 业务同时覆盖营销主站 + 帮助中心/文档站（如 `support.*`）等不同 host |
| 多语言/多区域 | 明显 locale 树（如 `/intl/`、多国站），不宜混在一个中文根册 |
| 产品线过宽 | 全量产品树或「文档分册」需求明确，根文件只能做门户 |
| 用户要求 | 用户明确说要分册 / 要分册方案 → **必须给方案** |

**倾向「不需要分册」**：

| 信号 | 说明 |
|------|------|
| 门户精选 | 单 host、条目明显低于上限（如几十条内）、分类清晰可扫读 |
| 数据不足 | 仅有营销页、尚无文档站材料，或仅 Sitemap 弱输入——先单文件门户，在待确认里提示「补抓取表 / 文档表后再分册」 |

**分册方案最少写清**：

1. 结论一句（需要 / 不需要 + 主因）  
2. 根 `llms.txt` 保留什么（门户入口 + `## 分册` 列表）  
3. 每个分册：建议路径（如 `/llms-support.txt`）、覆盖范围、数据来源（本 CSV 哪些路径 / 需另表）、预估条数级  
4. 若当前缺分册数据：标「待补抓取/待确认」，勿编造分册内 URL  

## 壳层与布局（必须同构 robots-txt-audit）

| 规则 | 要求 |
|------|------|
| 侧栏 | **不要** `#module-sidebar` |
| 顶栏 | 仅品牌 + 右侧按钮区（导出 PDF；可并列「下载 llms.txt」） |
| 品牌 | 「AI 亲和原则」→ `https://liminshuo.github.io/ascend-ai/principles-overview.html`（`target="_blank"`） |
| 顶栏对齐 | `.topbar-inner` 与正文同宽：`min(1000px, 100% - 2*gutter)` + `margin: 0 auto`；`justify-content: space-between` |
| 正文 | `.page-wrapper` `padding-top: var(--header-height, 56px)`；主区白底；内容栏最大 1000px |

## 报告结构（必须同构）

```
顶栏  品牌（左） · 导出 PDF / 下载 llms.txt（右）

H1  llms.txt 配置诊断 · {站点简称}
page-meta  示例站点（/llms.txt）· 实测日期 · 依据（部署 llms.txt 索引目录）

Part1. 当前配置分析                              ← H2
  当前 llms.txt（带标注）                        ← H3.aj-caption
    入口是否打开、robots 有没有声明、现网有没有索引、Sitemap 不能当 llms
  问题判定                                       ← H3
    ol + P0/P1/P2；数字写进每条，不要另做数据概况表 / 拉取结果表

Part2. llms.txt 的优化建议                       ← H2
  导语一句（精选、按主题、不灌全站）
  下载优化稿
  建议模板                                       ← H3.aj-caption
  修改说明                                       ← H3
    含是否分册一句；文档站另议
  待确认事项                                     ← H3
```

### 问题徽章

| class | 用途 |
|-------|------|
| `.sev-p0` | 关键推荐入口不可达、无任何可核验知识向 URL |
| `.sev-p1` | 大量重定向未解析、关键列缺失导致无法可靠分类 |
| `.sev-p2` | 重复 URL、说明过短、分类可再合并等 |
| `.sev-ask` | 待确认 / 待人工核验 |
| `.sev-ok` | 核验通过（可选） |

### 建议稿展示

- 默认：`<pre><code>` 内为**纯文本转义**的 llms.txt，**不要**整篇包 `<span class="add">` 等高亮背景
- 仅当与「旧版 llms」做逐条对比时，才可对**改过的字**局部使用 `.add` / `.ask`；不要全篇 `.keep`

## llms.txt 骨架

```markdown
# {站点名}

> {一句话范围}。本文件为精选索引入口，非全站 URL 枚举。

## {分类名}
- [{页面标题}](https://{绝对URL}): {一句可核验说明}
```

大站可增加分册：

```markdown
## 分册
- [{分册名}](https://{host}/llms-{slug}.txt): {分册范围一句}
```

## 调用示例

```
任务：基于网站抓取数据生成 llms.txt（有表 → Sitemap 轻量核对）

请分析 crawl/screaming-frog-export.csv，为 https://www.huaweicloud.com/ 生成 llms.txt。
有表时对 Sitemap 做轻量覆盖核对。按 llms-txt-generate Skill 输出 HTML 诊断报告与可下载的优化稿。
```

```
任务：无抓取表，仅用 Sitemap 弱输入

站点 https://example.com/ 暂无 CSV。请从 robots / sitemap.xml 作弱输入生成门户级 llms.txt，
报告标明质量受限，并按 Skill 输出 HTML 诊断与优化稿。
```

## 输出落盘（GEO）

| 文件 | 说明 |
|------|------|
| `docs/llms-audit-{slug}.html` | 主报告 |
| `report-serve/llms-audit-{slug}.html` | 同步副本 |
| `docs/exports/llms-{slug}.txt` | 优化后的 llms.txt（报告内 download） |
| `report-serve/exports/llms-{slug}.txt` | 同步副本 |
| Skill 目录 | `skills.html` 第二张卡片；详情 `skill-llms-txt-generate.html` |

## 可调整说明

编辑本目录 `SKILL.md` / `report-template.html` 后同步：

- 仓库：`.cursor/skills/llms-txt-generate/`
- 个人：`~/.cursor/skills/llms-txt-generate/`
- 下载包：`docs/exports/llms-txt-generate.zip`（与 report-serve 双份）

## 附加资源

- 可填壳模板：[report-template.html](report-template.html)
- 原则依据：GEO `docs/principles-llms.html`（llms.txt 索引入口可发现）
- 排版参照：`robots-txt-audit` 报告与 `docs/skill-robots-txt-audit.html`
