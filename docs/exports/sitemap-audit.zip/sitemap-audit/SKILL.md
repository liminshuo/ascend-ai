---
name: sitemap-audit
description: >-
  斜杠唤起。仅当用户输入 /sitemap-audit 时使用。后面可接站点根或 Sitemap URL。
  按 AI 亲和原则对站点 Sitemap 做轻量诊断：核验可达、规模与结构信号，对照 robots 声明。
  不灌全量 URL、不把 Sitemap 写成 llms.txt。
disable-model-invocation: true
---

# Sitemap 轻量诊断

单独斜杠 `/sitemap-audit` 仍可用。站点根走 `/geo-checklist-audit` 时会读本说明接力出稿，不要再让用户敲本斜杠。

## 核心命题

`sitemap.xml` 是给爬虫的 **URL 发现清单**。本 Skill 只做**轻量核对**：这份 Sitemap（及可选 index 子册）是否可达、规模与结构信号如何、与 robots 声明 / 抓取表是否对得上。**不是**全站内容审计，也**不是**把 Sitemap 拷成 `llms.txt`。

与 `robots-txt-audit` 分工：robots Skill 只查「文件内有没有 `Sitemap:` 绝对 URL」；本 Skill 查「Sitemap **本体**信号」。

## 输入（Agent 开跑前收齐）

| 字段 | 必填 | 说明 |
|------|------|------|
| **站点根或 Sitemap URL** | **是** | 只给根时从 `robots.txt` 的 `Sitemap:` 或 `/sitemap.xml` 发现；也可直接给 `https://www.huaweicloud.com/sitemap.xml` |
| **抓取表 CSV** | 可选 | 有则做「覆盖缺口」轻量对照（类型级）；不交也能跑。不要追问收录范围 |

## 范围（必守）

**要做**

| 项 | 要求 |
|----|------|
| 可达 | GET/HEAD Sitemap → 状态码、Content-Type、体积 |
| 类型 | `urlset` 或 `sitemapindex`；index 时有限层下钻（控制深度/子册数上限） |
| 规模 | `<loc>` 粗估条数；子册数（若 index） |
| 结构信号 | host 分布、http/https 比例、路径簇 Top（类型级） |
| 时效信号 | `lastmod` 分布是否异常陈旧（只作信号，不断言「必须更新」的业务结论） |
| robots 对照 | 站点根 `robots.txt` 是否以**绝对 URL**声明本 Sitemap（或等价条目） |
| 覆盖缺口 | **仅当有抓取表**：表未覆盖但 Sitemap 有 / 表有但 Sitemap 无（类型级） |
| 报告 | Part1 旧问题举证 + Part2 新旧对照与**可下载优化稿**；可导出 PDF |

**不要做**

- 把 Sitemap 全量 URL 列表贴进报告或写成 `llms.txt`
- 深挖 WAF / 训练合规法务
- 评价每一条 URL 的正文质量（那是 html-to-md / 页级探针）
- 替代 `robots-txt-audit` 做完整 Allow/Disallow 审计

## 工作流

```
Step 0  输入
        · 站点根或 Sitemap URL（必填）；可选抓取 CSV。不要追问收录范围
        · 读本 Skill

Step 1  拉取 Sitemap
        · GET 最终 URL；记状态码、体积、是否 XML
        · 判定 urlset / sitemapindex
        · index：抽样或有限层展开子 Sitemap（设上限，避免全站灌入上下文）

Step 2  轻量统计（类型级）
        · loc 条数；host / scheme 分布；路径前缀 Top N
        · lastmod 最早/最晚或「异常集中在旧日期」
        · 是否含文档站 / 帮助中心等其它 host（多入口信号）

Step 3  robots 对照
        · GET {站点根}/robots.txt
        · 是否存在 Sitemap: 绝对 URL；是否指向本文件或同族 index

Step 4  可选：与抓取表对照
        · 路径前缀 / host 级缺口；不输出全量差集 URL 列表

Step 5  问题判定 + Part2 优化稿
        · Part1 只列「问题判定」：每条标题一句 + 数字证据一句
        · **不要**单独写「当日拉取结果 / 关联探测」表
        · Part2 给可下载 XML 优化稿（根索引 + 分册样例）
        · P0：Sitemap 不可达且无替代发现入口
        · P1：robots 未声明；或清单严重过时 / 几乎全是 http 而站点已 https
        · P2：路径簇噪声占比高、缺文档 host、单文件混装等
        · 明确：勿把本清单灌进 llms.txt

Step 6  输出
        · docs/sitemap-audit-{slug}.html（及 report-serve 双写）
        · 顶栏导出 PDF
```

## 问题判定（速查）

| 严重度 | 何时 |
|--------|------|
| **P0** | Sitemap URL 不可达（且无可用的声明/替代入口） |
| **P1** | robots 未以绝对 URL 声明本 Sitemap；或 loc 几乎全 http、lastmod 整体停滞多年（信号强） |
| **P2** | 公告/新闻等噪声前缀占比过高；无帮助中心/文档 host；与抓取表覆盖明显错位 |
| **待确认** | index 子册是否应拆分、业务上是否仍维护该清单 |
| **OK** | 可达、已声明、规模与协议正常（相对站点） |

## 报告结构

```
H1  sitemap.xml 配置诊断 · {站点简称}
page-meta  Sitemap URL · 实测日期 · 依据（sitemap 原则）

Part1. 当前配置分析
  当前 sitemap.xml（带标注）
  问题判定（ol + P0/P1/P2；数字写进每条，不要另做拉取结果表）

Part2. sitemap.xml 的优化建议
  建议模板 · 根索引（只列各分册地址）
  建议模板 · 分册样例
  修改说明
  待确认事项
```

壳层同构 robots / llms 报告：无侧栏；顶栏品牌 +「下载优化稿」+ 导出 PDF；正文最大 1000px。成品：`docs/sitemap-audit-huaweicloud.html`；离线复制本目录 `report-template.html`。

建议模板里绿色 `.add` 只标新增或改写的行（如分册 `sitemapindex`）。不要把整份 XML 涂成 `.keep`。

### Part2 优化稿（必有）

- 必须给出**可下载的新 Sitemap 基线**（至少根 index；大站建议再附核心册样例）
- 文内写清：旧文件哪里不对、新文件改了什么；完整全量 URL 可由构建管道后续生成，样例须标明「基线/示意」
- 禁止只写散文建议而无 XML 优化入口

## 调用示例

```
按 sitemap-audit 轻量诊断
Sitemap：https://www.huaweicloud.com/sitemap.xml
站点根：https://www.huaweicloud.com/
（可选）抓取表：crawl/huaweicloud-internal_all.csv
```

## 输出落盘（GEO）

| 文件 | 说明 |
|------|------|
| `docs/sitemap-audit-{slug}.html` | 主报告 |
| `report-serve/sitemap-audit-{slug}.html` | 同步 |
| Skill | `.cursor/skills/sitemap-audit/` |
| zip | `docs/exports/sitemap-audit.zip` |

## 附加资源

- 可填壳模板：[report-template.html](report-template.html)
- 原则：`docs/principles-sitemap.html`
- 对照：`robots-txt-audit`（声明）、`llms-txt-generate`（有表时轻量核对 Sitemap）
