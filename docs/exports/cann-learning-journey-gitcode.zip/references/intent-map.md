# 意图 → 学习路径映射（CANN 学习中心）

> **本文件是「规则层」，不存数据。** 具体课程名、notebook 文件名、章节结构一律由
> `scripts/fetch_catalog.py` 在生成时现抓仓库最新目录，禁止在此写死（这是避免频繁改 skill 的关键）。

来源仓库：
`https://gitcode.com/cann/cann-learning-hub`

## 意图关键词 → 主题（key + 目标）

| 用户原话（示例） | 主题 key | 目标(goal) | 抓取目录（fetch_catalog.py 入参） |
|------------------|----------|------------|----------------------------------|
| 算子开发 / 自定义算子 / Ascend C | operator | 算子开发入门 | `tutorials/ascendc_operator_development`、`quick_start/first_custom_operator` |
| 大模型推理 / LLM 部署 / Qwen 推理 | inference | 大模型推理入门 | `quick_start/first_llm_inference`、`tutorials/llm_inference` |
| 大模型训练 / 微调 / SFT / RL | training | 大模型训练入门 | `tutorials/sft_training_pipeline`、`tutorials/rl_training_pipeline` |
| 推荐系统 / DeepFM / CTR / 召回 | recommend | 推荐系统开发 | `contrib/tutorials/torch-rechub` |
| 入门 CANN / 了解 NPU / 新手 | basics | CANN 基础入门 | `quick_start/cann_basics` |
| 应用开发 / 离线推理 / ACL / ATC | application | 应用开发（离线推理） | `reference_practice/yolov13_offline_inference` |
| 图框架 / GE / TorchAir / AutoFusion | graph | 图框架开发 | `tutorials/ge_development`、`tutorials/TorchAir_development`、`tutorials/autofusion_development` |
| 集合通信 / HCCL / HiXL / 多卡 | comm | 集合通信开发 | `tutorials/hccl_development`、`tutorials/hixl_development` |
| PyASC / PyPTO / Python 算子 | pyasc | 算子开发（Python 版） | `tutorials/pyasc_operator_development`、`tutorials/pypto_development` |
| CANNBot / AI 生成算子 | cannbot | CANNBot 算子生成 | `tutorials/CANNBot` |
| AI 应用 / RAG / 知识库问答 | ai_app | AI 应用开发 | `reference_practice/ai_application_development` |

## 各主题的阶段骨架（stage 结构，课程由 fetch_catalog.py 现抓填充）

> 阶段是「稳定的学习逻辑」，课程名/文件名是「易变的数据」。下面只给阶段划分与每阶段对应的抓取目录，
> 阶段内的具体课程卡由脚本按目录内 notebook 自动生成（跳过 `*chapter_intro*` / `*chapter_practice*` / `*chapter_test*` 等占位章）。

### operator（算子开发）
1. **CANN 基础知识** ← `quick_start/cann_basics`（AI 基础 / NPU / CANN 三讲）
2. **算子开发入门** ← `quick_start/first_custom_operator`
3. **Ascend C 算子开发** ← `tutorials/ascendc_operator_development`（核函数→Tiling→矩阵乘→融合）
4. **算子工程实战进阶** ← 同目录 `06_opensource_repo_*`、`07_Troubleshooting`、`08_performance_optimization`
5. **练习与在线体验** ← CANNJudge + CANNLab
- certificate：获得算子开发证书

### inference（大模型推理）
1. **CANN 基础知识** ← `quick_start/cann_basics`
2. **大模型推理入门** ← `quick_start/first_llm_inference`
3. **大模型推理系列课程** ← `tutorials/llm_inference`
4. **推理部署与优化** ← `tutorials/ge_development`、`autofusion_development`
5. **在线体验** ← CANNLab
- certificate：获得推理开发证书

### training（大模型训练）
1. **CANN 基础知识** ← `quick_start/cann_basics`
2. **SFT 监督微调** ← `tutorials/sft_training_pipeline`
3. **RL 强化学习训练** ← `tutorials/rl_training_pipeline`
4. **在线体验** ← CANNLab
- certificate：获得训练实践证书

### recommend（推荐系统）
1. **CANN 基础知识** ← `quick_start/cann_basics`
2. **推荐系统开发** ← `contrib/tutorials/torch-rechub`
3. **在线体验**
- certificate：获得推荐系统开发证书

### basics（CANN 基础入门）
1. **CANN 基础知识** ← `quick_start/cann_basics`（AI 基础 / NPU / CANN / NPU 实践）
2. **在线体验** ← CANNLab
- certificate：完成 CANN 入门

### application（应用开发 · 离线推理）
1. **CANN 基础知识** ← `quick_start/cann_basics`
2. **YOLOv13 离线推理实战** ← `reference_practice/yolov13_offline_inference`
3. **在线体验** ← CANNLab
- certificate：获得应用开发证书

### graph（图框架）
1. **CANN 基础知识** ← `quick_start/cann_basics`
2. **GE 图引擎** ← `tutorials/ge_development`
3. **TorchAir 图模式** ← `tutorials/TorchAir_development`
4. **AutoFusion 自动融合** ← `tutorials/autofusion_development`
5. **在线体验** ← CANNLab
- certificate：获得图框架开发证书

### comm（集合通信）
1. **CANN 基础知识** ← `quick_start/cann_basics`
2. **HCCL 集合通信** ← `tutorials/hccl_development`
3. **HiXL 单边通信** ← `tutorials/hixl_development`
4. **在线体验** ← CANNLab
- certificate：获得集合通信开发证书

### pyasc（算子开发 · Python 版）
1. **CANN 基础知识** ← `quick_start/cann_basics`
2. **PyASC 算子开发** ← `tutorials/pyasc_operator_development`
3. **PyPTO 算子开发** ← `tutorials/pypto_development`（可选姊妹路线）
4. **练习与在线体验** ← CANNJudge + CANNLab
- certificate：获得算子开发（Python 版）证书

### cannbot（CANNBot 算子生成）
1. **CANN 基础知识** ← `quick_start/cann_basics`
2. **CANNBot 入门与进阶** ← `tutorials/CANNBot`
3. **在线体验** ← CANNLab
- certificate：获得 CANNBot 开发证书

### ai_app（AI 应用开发）
1. **CANN 基础知识** ← `quick_start/cann_basics`
2. **AI 应用开发实践（RAG）** ← `reference_practice/ai_application_development`
3. **在线体验** ← CANNLab
- certificate：获得 AI 应用开发证书

## 公共阶段（所有主题的第一阶段）
- **CANN 基础知识** 恒定来自 `quick_start/cann_basics`，三讲 + 一实践，
  具体 notebook 由 fetch_catalog.py 抓取（当前为 01_ai_basics / 02_what_is_npu / 03_what_is_cann / 04_npu_practice）。

## 站外平台入口（可直接使用，不属仓库）
- CANNJudge 刷题：`https://cannjudge.cn`
- CANNLab 云端：`https://gitcode.com/org/cann/cannlab`
- CANN 大赛：仓库 README「学·练·赛」入口

## 主题覆盖度备忘
- 已覆盖 11 个主题（operator/inference/training/recommend/basics/application/graph/comm/pyasc/cannbot/ai_app）。
- **未纳入**（结构不匹配时间轴产物，仅作导读）：
  - `standard_course/` 标准课程体系（135 门原子课程总纲 + 启航营 + 教材区）——「总纲」非「单主题路径」，
    需要时单独生成「课程体系导读」而非旅程地图。

## 默认 persona
未明确说明时：角色=高校学生，目标=对应主题默认 goal，
技术水平=C++（operator）/ Python（其余）。
可根据对话中用户自述覆盖（如「我是新入门的开发人员」→ level=入门）。
