---
name: cann-learning-journey-gitcode
description: >-
  Builds a personalized CANN / 昇腾 learning journey map as one HTML page
  (staged path, course cards, certificate) from the live cann-learning-hub
  GitCode catalog. Use only when the user explicitly invokes
  /cann-learning-journey-gitcode, so it stays distinct from /ascend-learning-journey
  and from general CANN questions. If the command has no topic, ask which
  topic before generating. Topics include 算子开发, 推理, 训练, 推荐, NPU/CANN,
  应用开发, 图框架, 集合通信, PyASC, CANNBot, RAG.
disable-model-invocation: true
agent_created: true
---

# CANN 学习旅程地图生成器

## Overview
将一句学习意图（如「我想学一下算子开发」）转化为一份**个性化学习路径地图**，
输出为与用户提供的 CANN Bench「昇腾学习旅程地图」高保真原型同款的单页 HTML：
原型头图（含标题/手绘插画/Ascend 标志）+ 学习者画像（角色/目标/技术水平）
+ 竖向时间轴（左右交替课程卡片）+ 结业证书。
课程目录实时取自 `https://gitcode.com/cann/cann-learning-hub`。

## When to use
必须由用户显式输入 `/cann-learning-journey-gitcode` 才使用本 skill，用来和普通 CANN 问答、以及 `/ascend-learning-journey` 全景网格区分开。
- 斜杠后写了主题：直接出图。例如 `/cann-learning-journey-gitcode 我想学算子开发`。
- 只有斜杠、没有主题：先问清主题再出图。
- 没有这个斜杠时，不要因为出现「我想学算子 / 推理 / CANN」就自动套用本 skill。
- 主题范围：算子开发、Ascend C、大模型推理/训练、推荐系统、NPU/CANN 入门，
  或扩展方向（应用开发/离线推理、图框架、集合通信、Python 算子、CANNBot、AI 应用）。
- 用户希望得到**可视化、按阶段组织**的学习路线，而非纯文字罗列。
- 输出形态应是一个可打开/可分享的 HTML 页面。

### 触发词参考（按主题，帮助判断是否命中本 skill）
- 算子开发：我想学算子 / 自定义算子 / Ascend C / 核函数 / 算子性能优化
- 大模型推理：想学推理 / LLM 部署 / Qwen 推理 / 推理加速
- 大模型训练：想学训练 / 微调 / SFT / RL / 训练优化
- 推荐系统：推荐系统 / 推荐算法 / DeepFM / CTR / 召回
- CANN 基础：入门 CANN / 了解 NPU / 新手 / CANN 是啥
- 应用开发：应用开发 / 离线推理 / ACL / ATC / 模型部署上线
- 图框架：图框架 / GE / TorchAir / AutoFusion / 图编译
- 集合通信：集合通信 / HCCL / HiXL / 多卡通信
- Python 算子：PyASC / PyPTO / 用 Python 写算子
- CANNBot：CANNBot / AI 生成算子 / 算子代码生成
- AI 应用：AI 应用 / RAG / 知识库问答 / 智能体

### 触发词参考（资讯/案例类，走「技术博客墙」而非学习地图）
- 技术动态：CANN 有什么新技术 / 最近更新 / 最新特性 / 技术动态
- 实践案例：实践案例 / 客户案例 / 落地经验 / 最佳实践 / 别人怎么做的
- 直接点名：技术博客 / blogs / CANN 博客

### 示例提示词（用户常说的组合，画像 + 目标 + 诉求）
- 「/cann-learning-journey-gitcode 我是新入门的开发人员，想学一下推理」→ inference，画像="新入门"
- 「/cann-learning-journey-gitcode 我是开发人员，想获取更多算子开发的实践」→ operator，倾向实践增强
- 「/cann-learning-journey-gitcode 我有 CUDA 经验，想快速上手 CANN」→ basics，可点出 CANN vs CUDA 对照
- 「/cann-learning-journey-gitcode 想用 Python 写算子，不会 C++」→ pyasc
- 「/cann-learning-journey-gitcode 想给团队讲清 CANN 基础概念」→ basics，含配套课件

### 消歧规则（重要，避免做错版本）
- **学习意图 vs 资讯意图**（关键区分）：
  - 「我想**学** XXX」「怎么入门 XXX」→ 学习旅程地图（generate.py，时间轴）
  - 「CANN 有什么**新技术**」「**案例**/实践/动态/博客」「别人怎么做的」→ 技术博客墙（build_blog_wall.py，卡片墙）
- 一条消息若命中多个主题、或方向含糊（如仅说「开发」「了解 CANN」），
  **先 AskUserQuestion 确认方向**（算子/训练/推理/应用/全景等），不要自行假设。
- 本 skill 的入口是 `/cann-learning-journey-gitcode`。用户带 `/ascend-learning-journey` 前缀 = 要「5阶段×4路径全景网格地图」，与本 skill 不同，勿混淆。

## Workflow

> **首选「一条命令出图」**：解析出主题 key 后，直接调用 `generate.py`，内部自动完成
> 抓目录 → 分组 → 组 spec → 注入基础阶段 → 渲染，无需手写 spec。
> 只有当主题映射特殊（需自定义阶段/描述）时才走下方 Step 2~4 的手动路径。

### 快速路径（推荐，绝大多数情况用它）
```bash
python3 scripts/generate.py --topic <主题key> --out 输出路径.html [--role 角色] [--goal 目标] [--level 水平]
```
- `--topic` 取 11 个 key 之一（同 Step 1）。
- 脚本读 `scripts/topics.py`（主题→目录锚点/阶段骨架的真源），调 fetch_catalog 抓真实课程，
  自动把「CANN 基础知识」前置、把「练习与在线体验」追加，最后渲染 HTML。
- 仓库更新时无需改 skill——每次生成都抓最新。

### 博客快速路径（资讯/案例意图，走这里）
判断用户是「资讯/案例」意图（见上方触发词 + 消歧规则）时，生成**技术博客墙**而非学习地图：
```bash
python3 scripts/build_blog_wall.py --out 输出路径.html
```
- 脚本内部调 `fetch_catalog.py --blogs` 抓 `blogs/` 下全部技术博客，
  标题/摘要直接读 md 文件（博客自带中文标题，不靠词典翻译），
  按「算子开发 / 大模型推理 / 大模型训练」三分类渲染成卡片墙。
- 博客 = 最新技术特性 + 行业动态 + 真实客户实践案例，形态是卡片墙（非时间轴）。

### Step 1 — 解析意图
从用户原话抽取：
- **意图类型**：学习（→ 课程地图）还是资讯/案例（→ 博客墙），按消歧规则判断。
- **主题**（对照 `references/intent-map.md` 或 `scripts/topics.py` 的「意图关键词 → 主题」表，共 11 个）：
  operator / inference / training / recommend / basics /
  application（应用开发·离线推理）/ graph（图框架 GE·TorchAir·AutoFusion）/
  comm（集合通信 HCCL·HiXL）/ pyasc（PyASC·PyPTO Python 算子）/
  cannbot（CANNBot 算子生成）/ ai_app（AI 应用·RAG）。
- **画像**（可选，缺省用 topics.py 默认值）：角色、目标、技术水平。
  若用户自述了身份/基础（如「我是新入门的开发人员」），覆盖默认值。
- 注：`standard_course/`（135 门原子课程体系）结构为「总纲」而非单主题路径，
  不生成旅程地图；用户若要，单独出「课程体系导读」。

### Step 2 — 手动路径：抓取实时课程目录（仅当需自定义时）
用 WebFetch 获取仓库主页，prompt 类似：
“列出该 CANN 学习中心仓库的课程/教程名称、所属场景（算子/推理/训练/推荐/基础）以及对应目录或链接。”
- 若抓取成功：以实时目录为准，挑选与主题相关的课程填入各阶段。
- 若抓取失败/不全：回退到 `references/intent-map.md` 中该主题的推荐阶段与课程。

### Step 2.5 — 校验真实文件路径（关键：禁止“猜文件名”）
GitCode 的 `blob/tree` 页面即使文件不存在也返回 HTTP 200（SPA 兜底页），
**不能用状态码判断链接对错**。课程内容必须由仓库真实文件名生成，**优先用封装的抓取脚本**：

1. **首选：用 `scripts/fetch_catalog.py` 抓真实目录**（可靠，已实测）：
   ```bash
   python3 scripts/fetch_catalog.py --dirs <仓库内目录> --as-courses --format md
   ```
   脚本内部用 git sparse-checkout（浅克隆 + 不下载 blob）拉取目标目录树，
   用 `find` 列出真实 `.ipynb`/`.md` 文件名，并自动跳过
   `*chapter_intro*` / `*chapter_practice*` / `*answer*` 等占位章。
   用其输出的真实文件名拼 `link`：`https://gitcode.com/cann/cann-learning-hub/blob/master/<真实路径>`。
   首次运行会 clone（约数秒），之后复用缓存（加 `--refresh` 强制增量更新）。

2. **兜底：WebFetch 打开父目录页**，prompt 要求原样列出真实文件名。

3. **禁止使用模型自行推断的文件名**（如随意编号 `01_xxx.ipynb`）。

4. 站外平台链接（cannjudge.cn、competition.gitcode.com）来自仓库 README 的「学·练·赛」入口，可直接使用。

> **数据与规则分离**：`references/intent-map.md` 只存「主题 → 抓取目录」锚点与阶段骨架，
> **不存课程名/文件名**。课程内容每次生成时现抓，仓库更新无需改 skill。

### Step 3 — 组装路径规格（JSON）
构造如下 JSON（stages 顺序即学习顺序，每门课可带 `link`）：
```json
{
  "title": "昇腾学习旅程地图",
  "subtitle": "按照您的技术方向，为您推荐最优的学习路径",
  "persona": {"role": "高校学生", "goal": "算子开发入门", "level": "C++"},
  "stages": [
    {"label": "CANN基础知识", "courses": [
      {"title": "人工智能基础", "desc": "AI 发展历程、算子概念", "link": "https://gitcode.com/cann/cann-learning-hub", "online": true}
    ]}
  ],
  "certificate": "获得初级证书",
  "source": "https://gitcode.com/cann/cann-learning-hub"
}
```
- `courses[].online`：是否显示「在线体验」标签（默认 true）。
- `courses[].link`：点击卡片跳转的真实 GitCode 链接（见 Step 2.5）。

### Step 4 — 渲染 HTML
调用脚本（确定性渲染，保证视觉一致）：
```bash
python3 scripts/build_map.py --input spec.json --out 输出路径.html [--with-basics]
```
- `--with-basics`：spec 里未写「CANN 基础知识」阶段时，自动前置公共基础阶段
  （AI 基础 / NPU / CANN / NPU 实践 四门，链接走 quick_start/cann_basics 真实文件），省去手动复制。
脚本内置 CANN Bench「学习」页设计 Token，并内嵌原型资源
（`assets/header.png` 头图、`assets/cert.png` 证书图标、`assets/link.svg` 外链图标），
无需联网即可查看。

### Step 4.5 — 校验站外链接（可选）
对 spec 中的**非 GitCode 仓库内**链接（cannjudge.cn、competition.gitcode.com 等）
跑一次可达性检查，拦截明显拼错：
```bash
python3 scripts/verify_links.py --input spec.json
```
（注：GitCode 仓库内 blob/tree 链接会显示为 SKIP，因为它们始终返回 200，
正确性已由 Step 2.5 的目录页文件名保证。）

### Step 5 — 呈现结果
用 `present_files` 打开生成的 HTML（本地预览面板），并附一句话说明：
该地图依据实时仓库目录生成，课程卡片可点击跳转到对应学习资源。

## Design notes（与用户原型对齐）
视觉严格对齐 `C:/Users/jingwen/Desktop/大模型训练学习旅程地图.html` 所代表的「第二版」样式
（即 CANN Bench「学习」页竖向时间轴风格）：
- **头图（header.png）**：页面顶部整宽横幅，原型导出图，含标题/手绘插画/Ascend 标志，
  下方圆角收口（原型 头图 组合 91336028）。
- **画像栏（subbar）**：白卡浮于头图下沿，含副标题 + 3 个画像 chip
  （角色 / 目标 / 技术水平），各 chip 显示键-值（原型 筛选栏）。
- **竖向时间轴（journey）**：贯穿页面中线的竖向细线；每个学习阶段是一个 `.stage`：
  - 阶段标题为居中的圆角 pill（`.stage-label`，如「CANN基础知识」）。
  - 阶段内每门课程是一张 `.step` 卡片，**左右交替**排布于时间轴两侧，
    中间有编号里程碑圆点（`.step-marker`，序号 1、2、3…）；
    课程卡含标题 + 描述 + 「在线体验」蓝色 pill + 外链图标（`link.svg`）。
- **结业证书（cert）**：底部白卡，左侧证书图标（`cert.png`）+ 红色标题「获得初级证书」+ 说明。
- 设计 Token 见 `scripts/build_map.py` 中 `TOKENS`：页面背景 `#F4F5F7`、主色 `#1456F0`
  （在线体验/外链）、证书红 `#C7000B`、边框 `#E5E7EB`、时间轴线 `#D1D5DB`。

## Resources
- `scripts/generate.py` — **端到端出图入口**（`--topic` + 画像 → 自动抓目录分组组 spec 渲染，首选）。
- `scripts/topics.py` — 主题→目录锚点/阶段骨架/默认画像的**唯一真源**（数据层，供 generate.py 消费）。
- `scripts/fetch_catalog.py` — 用 git sparse-checkout 可靠抓仓库真实目录（列 notebook 文件名，自动跳过占位章；`--as-courses` 输出带中文标题 + `_chapter` 字段的课程卡；`--blogs` 抓技术博客标题+摘要）。
- `scripts/build_blog_wall.py` — 技术博客/实践案例墙渲染器（资讯/案例意图用，三分类卡片墙）。
- `scripts/build_map.py` — JSON 规格 → 旅程地图 HTML 渲染器（核心，内嵌原型资源；`--with-basics` 自动前置公共基础阶段）。
- `scripts/verify_links.py` — 站外链接可达性检查（GitCode 站内链接会自动 SKIP）。
- `references/intent-map.md` — 意图关键词映射、各主题「抓取目录锚点 + 阶段骨架」的人类可读版（与 topics.py 同义）。
- `assets/header.png`、`assets/cert.png`、`assets/link.svg` — 原型导出资源，已 base64 内嵌进 HTML。

## 链接可靠性说明（重要）
- 仓库内链接：`https://gitcode.com/cann/cann-learning-hub/blob|tree/master/<真实路径>`，
  必须由 **Step 2.5 的目录页真实文件名**拼出，禁止猜测；GitCode 对不存在的文件也返回 200，
  故无法用 HTTP 状态码校验，唯一可靠依据是目录页列出的真实文件。
- 站外链接：cannjudge.cn、competition.gitcode.com 等，来自仓库 README 的学·练·赛入口。
