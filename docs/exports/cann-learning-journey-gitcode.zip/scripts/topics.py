# -*- coding: utf-8 -*-
"""
topics.py — 主题 → 目录锚点 与 阶段骨架（数据层，供 generate.py 使用）

这是「规则层」的唯一真源（与 references/intent-map.md 同义，但以 Python 形式供脚本消费）。
课程名/notebook 文件名一律由 fetch_catalog.py 现抓，这里只存：
  - 主题 key → 目标(goal) + 默认技术水平(level)
  - 主题 key → 若干条「阶段」（每条阶段 = 阶段名 + 抓取目录列表）
阶段内的课程由 fetch_catalog.py 抓目录后按 _chapter 自动分组填入。

⚠️ 阶段名/目录可能随仓库演进，但比「具体课程」稳定得多；仓库增加新课程时，本文件通常无需改。
"""

TOPICS = {
    "operator": {
        "goal": "算子开发入门", "level": "C++",
        "stages": [
            {"label": "算子开发入门", "dirs": ["quick_start/first_custom_operator"]},
            {"label": "Ascend C 算子开发", "dirs": ["tutorials/ascendc_operator_development"]},
        ],
        "practice_dir": None,
        "certificate": "获得算子开发初级证书",
    },
    "inference": {
        "goal": "大模型推理开发", "level": "Python",
        "stages": [
            {"label": "大模型推理入门", "dirs": ["quick_start/first_llm_inference"]},
            {"label": "大模型推理系列课程", "dirs": ["tutorials/llm_inference"]},
            {"label": "推理部署与优化", "dirs": ["tutorials/ge_development", "tutorials/autofusion_development"]},
        ],
        "practice_dir": None,
        "certificate": "获得大模型推理开发证书",
    },
    "training": {
        "goal": "大模型训练开发", "level": "Python",
        "stages": [
            {"label": "SFT 监督微调", "dirs": ["tutorials/sft_training_pipeline"]},
            {"label": "RL 强化学习训练", "dirs": ["tutorials/rl_training_pipeline"]},
        ],
        "practice_dir": None,
        "certificate": "获得训练实践证书",
    },
    "recommend": {
        "goal": "推荐系统开发", "level": "Python",
        "stages": [
            {"label": "推荐系统开发", "dirs": ["contrib/tutorials/torch-rechub"]},
        ],
        "practice_dir": None,
        "certificate": "获得推荐系统开发证书",
    },
    "basics": {
        "goal": "CANN 基础入门", "level": "入门",
        "stages": [
            {"label": "CANN 基础知识", "dirs": ["quick_start/cann_basics"]},
        ],
        "practice_dir": None,
        "certificate": "完成 CANN 基础入门",
    },
    "application": {
        "goal": "应用开发（离线推理）", "level": "Python",
        "stages": [
            {"label": "YOLOv13 离线推理实战", "dirs": ["reference_practice/yolov13_offline_inference"]},
        ],
        "practice_dir": None,
        "certificate": "获得应用开发证书",
    },
    "graph": {
        "goal": "图框架开发", "level": "Python",
        "stages": [
            {"label": "GE 图引擎", "dirs": ["tutorials/ge_development"]},
            {"label": "TorchAir 图模式", "dirs": ["tutorials/TorchAir_development"]},
            {"label": "AutoFusion 自动融合", "dirs": ["tutorials/autofusion_development"]},
        ],
        "practice_dir": None,
        "certificate": "获得图框架开发证书",
    },
    "comm": {
        "goal": "集合通信开发", "level": "Python",
        "stages": [
            {"label": "HCCL 集合通信", "dirs": ["tutorials/hccl_development"]},
            {"label": "HiXL 单边通信", "dirs": ["tutorials/hixl_development"]},
        ],
        "practice_dir": None,
        "certificate": "获得集合通信开发证书",
    },
    "pyasc": {
        "goal": "算子开发（Python 版）", "level": "Python",
        "stages": [
            {"label": "PyASC 算子开发", "dirs": ["tutorials/pyasc_operator_development"]},
            {"label": "PyPTO 算子开发", "dirs": ["tutorials/pypto_development"]},
        ],
        "practice_dir": None,
        "certificate": "获得算子开发（Python 版）证书",
    },
    "cannbot": {
        "goal": "CANNBot 算子生成", "level": "Python",
        "stages": [
            {"label": "CANNBot 入门与进阶", "dirs": ["tutorials/CANNBot"]},
        ],
        "practice_dir": None,
        "certificate": "获得 CANNBot 开发证书",
    },
    "ai_app": {
        "goal": "AI 应用开发", "level": "Python",
        "stages": [
            {"label": "AI 应用开发实践（RAG）", "dirs": ["reference_practice/ai_application_development"]},
        ],
        "practice_dir": None,
        "certificate": "获得 AI 应用开发证书",
    },
}

# 默认 persona（用户未指定时）
DEFAULT_ROLE = "开发人员"

# 附加的「练习与在线体验」阶段（所有主题通用，置于末尾）
PRACTICE_STAGE = {
    "label": "练习与在线体验",
    "courses": [
        {"title": "算子刷题评测 · CANNJudge", "desc": "Ascend 算子编程在线刷题，实时评测",
         "link": "https://cannjudge.cn", "online": True},
        {"title": "在线体验 · CANNLab", "desc": "一键启动云端 NPU 环境，免配置直接实操",
         "link": "https://gitcode.com/org/cann/cannlab", "online": True},
    ],
}


def get_topic(key):
    if key not in TOPICS:
        raise KeyError(f"未知主题 '{key}'，可选：{', '.join(sorted(TOPICS))}")
    return TOPICS[key]